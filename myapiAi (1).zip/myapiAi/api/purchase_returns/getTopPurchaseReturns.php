<?php
  header("Access-Control-Allow-Origin: *");
  header("Access-Control-Allow-Headers: access");
  header("Access-Control-Allow-Methods: GET");
  header("Content-Type: application/json; charset=UTF-8");
  header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

  require_once '../../config/Database.php';
  require_once '../../models/Purchase_returns.php';

  $database = new Database();
  $db = $database->getConnection();

  $purchaseReturn = new Purchase_returns($db);

  $store_id = isset($_GET['store_id']) ? $_GET['store_id'] : null;
  $yearId = isset($_GET['yearId']) ? $_GET['yearId'] : null;

  if (!$store_id || !$yearId) {
      http_response_code(400);
      echo json_encode(array("message" => "Missing required parameters: store_id, yearId"));
      exit();
  }

  try {
      // Set properties
      $purchaseReturn->store_id = $store_id;
      $purchaseReturn->yearId = $yearId;
      
      // Get purchase returns
      $stmt = $purchaseReturn->getTopPurchaseReturns();
      $purchaseReturns = [];
      
      while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
          // Add calculated final amount after discount
          $row['finalAmount'] = $row['tot_pr'] - $row['discount'];
          array_push($purchaseReturns, $row);
      }

      // Return response
      if (count($purchaseReturns) > 0) {
          http_response_code(200);
          echo json_encode(array(
              "message" => "Purchase returns retrieved successfully",
              "data" => $purchaseReturns
          ));
      } else {
          http_response_code(404);
          echo json_encode(array("message" => "No record Found"));
      }

  } catch (Exception $e) {
      http_response_code(500);
      echo json_encode(array(
          "message" => "Internal server error: " . $e->getMessage()
      ));
  }
?>