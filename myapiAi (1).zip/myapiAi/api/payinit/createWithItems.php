<?php 
  // Headers
  header('Access-Control-Allow-Origin: *');
  header('Content-Type: application/json');
  header('Access-Control-Allow-Methods: POST');
  header('Access-Control-Allow-Headers: Access-Control-Allow-Headers,Content-Type,Access-Control-Allow-Methods, Authorization, X-Requested-With');

  // Handle preflight OPTIONS request
  if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
      http_response_code(200);
      exit();
  }

include_once '../../config/Database.php';
include_once '../../models/payinit.php';
 
include_once '../../models/payinit_details.php';

// Get database connection
$database = new Database();
$db = $database->connect();

// Initialize models
$payinit = new Pay_init($db);
$payinit_details = new Pay2_details($db);

// Get posted data
$raw_input = file_get_contents("php://input");
$data = json_decode($raw_input, true);

if (!$data) {
    http_response_code(400);
    echo json_encode(['message' => 'Invalid JSON data']);
    exit;
}

// Start transaction
$db->beginTransaction();

try {
    // Extract invoice data and items
    $invoiceData = $data['invoice'];
    $itemsList = $data['items'];
    
    // Validate required data
    if (!$invoiceData || !$itemsList || !is_array($itemsList)) {
        throw new Exception('Missing required invoice or items data');
    }
    
    // Set invoice properties
    $payinit->pay_ref = $invoiceData['pay_ref'] ?? '';
    $payinit->tot_pr = $invoiceData['tot_pr'] ?? 0;
    $payinit->pay = $invoiceData['pay'] ?? 0;
    $payinit->changee = $invoiceData['changee'] ?? 0;
    $payinit->user_id = $invoiceData['user_id'] ?? 0;
    $payinit->store_id = $invoiceData['store_id'] ?? 0;
    $payinit->pay_date = $invoiceData['pay_date'] ?? date('Y-m-d');
    $payinit->pay_time = $invoiceData['pay_time'] ?? date('H:i:s');
    $payinit->nextPay = $invoiceData['nextPay'] ?? null;
    $payinit->discount = $invoiceData['discount'] ?? 0;
    $payinit->payComment = $invoiceData['payComment'] ?? '';
    $payinit->cust_id = $invoiceData['cust_id'] ?? 0;
    $payinit->pay_method = $invoiceData['pay_method'] ?? 'cash';
    
    // Create initial invoice
    if (!$payinit->create()) {
        throw new Exception('Unable to create initial invoice');
    }
    
    // Get the created invoice ID
    $created_pay_id = $payinit->pay_id;
    
    // Process items
    $itemsCreated = 0;
    foreach ($itemsList as $item) {
        // Set item properties
        $payinit_details->item_id = $item['item_id'];
        $payinit_details->pay_ref = $invoiceData['pay_ref'];
        $payinit_details->item_name = $item['item_name'];
        $payinit_details->pay_price = $item['pay_price'];
        $payinit_details->quantity = $item['quantity'];
        $payinit_details->tot = $item['tot'];
        $payinit_details->store_id = $invoiceData['store_id'];
        $payinit_details->dateCreated = $item['dateCreated'] ?? date('Y-m-d H:i:s');
        $payinit_details->perch_price = $item['perch_price'] ?? 0;
        
        // Create item
        if ($payinit_details->create()) {
            $itemsCreated++;
        } else {
            throw new Exception('Unable to create item: ' . $item['item_name']);
        }
    }
    
    // Commit transaction
    $db->commit();
    
    // Return success response
    http_response_code(201);
    echo json_encode([
        'message' => 'Initial invoice and items created successfully',
        'pay_id' => $created_pay_id,
        'items_created' => $itemsCreated,
        'success' => true
    ]);
    
} catch (Exception $e) {
    // Rollback transaction on error
    $db->rollback();
    
    http_response_code(400);
    echo json_encode([
        'message' => 'Failed to create initial invoice: ' . $e->getMessage(),
        'success' => false
    ]);
}
?>