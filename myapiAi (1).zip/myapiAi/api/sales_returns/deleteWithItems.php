<?php 
  // Headers
  header('Access-Control-Allow-Origin: *');
  header('Content-Type: application/json');
  header('Access-Control-Allow-Methods: DELETE, POST');
  header('Access-Control-Allow-Headers: Access-Control-Allow-Headers,Content-Type,Access-Control-Allow-Methods, Authorization, X-Requested-With');

  include_once '../../config/Database.php';
  include_once '../../models/Sales_returns.php';
  include_once '../../models/Sales_return_details.php';

  // Instantiate DB & connect
  $database = new Database();
  $db = $database->connect();

  // Instantiate objects
  $return_invoice = new Sales_returns($db);
  $return_details = new Sales_return_details($db);

  // Get raw posted data
  $data = json_decode(file_get_contents("php://input"));

  if (!$data) {
    echo json_encode(
      array('success' => false, 'message' => 'No data provided')
    );
    exit();
  }

  // Check for return_id or return_ref
  if (!isset($data->return_id) && !isset($data->return_ref)) {
    echo json_encode(
      array('success' => false, 'message' => 'Missing required parameter: return_id or return_ref')
    );
    exit();
  }

  // Start transaction
  $db->beginTransaction();

  try {
    // Set return reference for details deletion
    if (isset($data->return_ref)) {
      $return_details->return_ref = $data->return_ref;
    } else if (isset($data->return_id)) {
      // If only return_id provided, we need to get return_ref first
      // This is a simplified approach - in production you might want to query the return_ref first
      $return_details->return_ref = isset($data->return_ref_backup) ? $data->return_ref_backup : '';
    }

    // Delete return details first (foreign key constraint)
    if (!empty($return_details->return_ref)) {
      if (!$return_details->deleteMultiServices()) {
        throw new Exception('Failed to delete return items');
      }
    }

    // Delete return invoice
    if (isset($data->return_id)) {
      $return_invoice->return_id = $data->return_id;
      if (!$return_invoice->delete()) {
        throw new Exception('Failed to delete return invoice');
      }
    } else if (isset($data->return_ref)) {
      $return_invoice->return_ref = $data->return_ref;
      if (!$return_invoice->deleteByRef()) {
        throw new Exception('Failed to delete return invoice');
      }
    }

    // Commit transaction
    $db->commit();

    // Return success response
    echo json_encode(
      array(
        'success' => true,
        'message' => 'Return invoice deleted successfully'
      )
    );

  } catch (Exception $e) {
    // Rollback transaction
    $db->rollback();
    
    // Return error response
    echo json_encode(
      array(
        'success' => false,
        'message' => 'Error deleting return invoice: ' . $e->getMessage()
      )
    );
  }
?>