<?php
header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Headers: X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Access-Control-Request-Method");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");
header("Allow: GET, POST, OPTIONS, PUT, DELETE");
header("Content-Type: application/json; charset=UTF-8");

$method = $_SERVER['REQUEST_METHOD'];
if($method == "OPTIONS") {
    die();
}

include_once '../../config/Database.php';

$database = new Database();
$db = $database->connect();

// Get parameters
$store_id = isset($_GET['store_id']) ? $_GET['store_id'] : die('{"success": false, "message": "Missing store_id parameter"}');
$start_date = isset($_GET['start_date']) ? $_GET['start_date'] : die('{"success": false, "message": "Missing start_date parameter"}');
$end_date = isset($_GET['end_date']) ? $_GET['end_date'] : die('{"success": false, "message": "Missing end_date parameter"}');
$year_id = isset($_GET['year_id']) ? $_GET['year_id'] : die('{"success": false, "message": "Missing year_id parameter"}');

try {
    // Get sales and purchase totals for the period
    $sales_stmt = $db->prepare("
        SELECT 
            COALESCE(SUM(tot_pr - discount), 0) as total_sales,
            COUNT(*) as sales_count
        FROM pay 
        WHERE store_id = ? AND yearId = ? 
        AND pay_date >= ? AND pay_date <= ?
    ");
    $sales_stmt->execute([$store_id, $year_id, $start_date, $end_date]);
    $sales_result = $sales_stmt->fetch(PDO::FETCH_ASSOC);

    $purchase_stmt = $db->prepare("
        SELECT 
            COALESCE(SUM(tot_pr - discount), 0) as total_purchases,
            COUNT(*) as purchases_count
        FROM perch 
        WHERE store_id = ? AND yearId = ? 
        AND pay_date >= ? AND pay_date <= ?
    ");
    $purchase_stmt->execute([$store_id, $year_id, $start_date, $end_date]);
    $purchase_result = $purchase_stmt->fetch(PDO::FETCH_ASSOC);

    // Get daily chart data for the period
    $chart_stmt = $db->prepare("
        SELECT 
            DATE(COALESCE(p.pay_date, pr.pay_date)) as date,
            COALESCE(SUM(CASE WHEN p.pay_date IS NOT NULL THEN (p.tot_pr - p.discount) ELSE 0 END), 0) as sales,
            COALESCE(SUM(CASE WHEN pr.pay_date IS NOT NULL THEN (pr.tot_pr - pr.discount) ELSE 0 END), 0) as purchase
        FROM (
            SELECT pay_date FROM pay 
            WHERE store_id = ? AND yearId = ? 
            AND pay_date >= ? AND pay_date <= ?
            UNION
            SELECT pay_date FROM perch 
            WHERE store_id = ? AND yearId = ? 
            AND pay_date >= ? AND pay_date <= ?
        ) as dates
        LEFT JOIN pay p ON DATE(p.pay_date) = DATE(dates.pay_date) 
            AND p.store_id = ? AND p.yearId = ?
        LEFT JOIN perch pr ON DATE(pr.pay_date) = DATE(dates.pay_date) 
            AND pr.store_id = ? AND pr.yearId = ?
        GROUP BY DATE(COALESCE(p.pay_date, pr.pay_date))
        ORDER BY date ASC
    ");
    $chart_stmt->execute([
        $store_id, $year_id, $start_date, $end_date,
        $store_id, $year_id, $start_date, $end_date,
        $store_id, $year_id,
        $store_id, $year_id
    ]);
    $chart_data = $chart_stmt->fetchAll(PDO::FETCH_ASSOC);

    // Format dates for better display
    foreach ($chart_data as &$data) {
        $data['date'] = date('Y-m-d', strtotime($data['date']));
        $data['sales'] = floatval($data['sales']);
        $data['purchase'] = floatval($data['purchase']);
    }

    $response = array(
        "success" => true,
        "data" => array(
            "total_sales" => floatval($sales_result['total_sales']),
            "total_purchase" => floatval($purchase_result['total_purchases']),
            "sales_count" => intval($sales_result['sales_count']),
            "purchases_count" => intval($purchase_result['purchases_count']),
            "chart_data" => $chart_data,
            "period" => array(
                "start_date" => $start_date,
                "end_date" => $end_date
            )
        ),
        "message" => "Sales and purchase data retrieved successfully"
    );

    http_response_code(200);
    echo json_encode($response);

} catch(Exception $e) {
    http_response_code(500);
    echo json_encode(array(
        "success" => false,
        "message" => "Error retrieving sales and purchase data",
        "error" => $e->getMessage()
    ));
}
?>