<?php
  header("Access-Control-Allow-Origin: *");
  header("Access-Control-Allow-Headers: access");
  header("Access-Control-Allow-Methods: POST");
  header("Content-Type: application/json; charset=UTF-8");
  header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

  require_once '../../config/Database.php';
  require_once '../../models/Purchase_returns.php';
  require_once '../../models/Purchase_return_details.php';

  $database = new Database();
  $db = $database->getConnection();

  $purchaseReturn = new Purchase_returns($db);
  $purchaseReturnDetails = new Purchase_return_details($db);

  // Get raw posted data
  $data = json_decode(file_get_contents("php://input"));

  if (!$data || !isset($data->return_ref) || !isset($data->store_id) || !isset($data->yearId)) {
      http_response_code(400);
      echo json_encode(array("message" => "Missing required data: return_ref, store_id, yearId"));
      exit();
  }

  try {
      // Begin transaction
      $db->beginTransaction();

      // Set properties for deletion
      $purchaseReturn->return_ref = $data->return_ref;
      $purchaseReturn->store_id = $data->store_id;
      $purchaseReturn->yearId = $data->yearId;

      $purchaseReturnDetails->return_ref = $data->return_ref;
      $purchaseReturnDetails->store_id = $data->store_id;
      $purchaseReturnDetails->yearId = $data->yearId;

      // Delete return items first
      if ($purchaseReturnDetails->deleteByReturnRef()) {
          
          // Delete the purchase return
          if ($purchaseReturn->delete()) {
              
              // Commit transaction
              $db->commit();

              // Return success response
              http_response_code(200);
              echo json_encode(array(
                  "message" => "Purchase return deleted successfully",
                  "return_ref" => $data->return_ref
              ));

          } else {
              throw new Exception("Failed to delete purchase return");
          }

      } else {
          throw new Exception("Failed to delete purchase return items");
      }

  } catch (Exception $e) {
      // Rollback transaction on error
      $db->rollBack();
      
      http_response_code(500);
      echo json_encode(array(
          "message" => "Failed to delete purchase return: " . $e->getMessage()
      ));
  }
?>