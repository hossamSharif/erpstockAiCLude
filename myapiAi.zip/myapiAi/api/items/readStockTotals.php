<?php 
  // Headers
  header('Access-Control-Allow-Origin: *');
  header('Content-Type: application/json');

  include_once '../../config/Database.php';
  include_once '../../models/items.php';

  // Instantiate DB & connect
  $database = new Database();
  $db = $database->connect();

  // Instantiate items object
  $invoice = new Items($db);

  // Get parameters (only store_id, yearId, and category_id)
  $invoice->store_id = isset($_GET['store_id']) ? $_GET['store_id'] : die();
  $invoice->yearId = isset($_GET['yearId']) ? $_GET['yearId'] : die();
  $invoice->category_id = isset($_GET['category_id']) ? $_GET['category_id'] : 'all';

  // Get totals (no additional filters)
  $result = $invoice->getStockTotals();
   
  if($result) {
    // Return totals
    echo json_encode(array(
      'message' => 'Totals calculated successfully',
      'data' => $result
    ));
  } else {
    // No data
    echo json_encode(array(
      'message' => 'No data found', 
      'data' => array(
        'stockValuePayPrice' => 0,
        'stockValuePerchPrice' => 0,
        'items_count' => 0
      )
    ));
  }
?>