<?php
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Accept');

// Handle preflight
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Log everything to a file
$log_data = [
    'timestamp' => date('Y-m-d H:i:s'),
    'method' => $_SERVER['REQUEST_METHOD'],
    'content_type' => $_SERVER['CONTENT_TYPE'] ?? 'not set',
    'content_length' => $_SERVER['CONTENT_LENGTH'] ?? 'not set',
    'raw_input' => file_get_contents("php://input"),
    'post_data' => $_POST,
    'get_data' => $_GET,
    'all_headers' => getallheaders(),
    'request_uri' => $_SERVER['REQUEST_URI'] ?? 'not set'
];

file_put_contents('../../simple_test_log.txt', json_encode($log_data, JSON_PRETTY_PRINT) . "\n\n", FILE_APPEND);

echo json_encode([
    'success' => true,
    'received_method' => $_SERVER['REQUEST_METHOD'],
    'raw_input_length' => strlen(file_get_contents("php://input")),
    'timestamp' => date('Y-m-d H:i:s')
]);
?>