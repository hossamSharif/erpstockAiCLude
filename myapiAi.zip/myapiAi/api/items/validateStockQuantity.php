<?php 
// Headers
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Access-Control-Allow-Headers,Content-Type,Access-Control-Allow-Methods, Authorization, X-Requested-With');

include_once '../../config/Database.php';
include_once '../../models/items.php';

// Instantiate DB & connect
$database = new Database();
$db = $database->connect();

// Instantiate items object
$items = new Items($db);

// Get POST data
$data = json_decode(file_get_contents("php://input"));

// Validate required parameters
if (!isset($data->store_id) || !isset($data->itemList) || !is_array($data->itemList)) {
    echo json_encode(array(
        'success' => false,
        'message' => 'Missing required parameters: store_id and itemList are required'
    ));
    exit();
}

$store_id = $data->store_id;
$itemList = $data->itemList;
$insufficientItems = array();

try {
    foreach ($itemList as $item) {
        // Validate item structure
        if (!isset($item->item_id) || !isset($item->quantity)) {
            continue; // Skip invalid items
        }
        
        $items->id = $item->item_id;
        $items->store_id = $store_id;
        
        // Get current stock quantity using the existing method from items model
        $result = $items->readItemByIdQty();
        $num = $result->rowCount();
        
        if ($num > 0) {
            $row = $result->fetch(PDO::FETCH_ASSOC);
            extract($row);
            
            // Calculate available quantity using the same logic as readAllStock.php
            $firstQuantity = floatval($firstQuantity);
            $perchQuantity = floatval($perchQuantity);
            $salesQuantity = floatval($salesQuantity);
            $tswiaQuantity = floatval($tswiaQuantity);
            
            // Adjust for tswia differences (same logic as readAllStock.php)
            if (($availQty - $qtyReal) < 0) {
                $perchQuantity += abs($availQty - $qtyReal);
            } else if (($availQty - $qtyReal) > 0) {
                $salesQuantity += ($availQty - $qtyReal);
            }
            
            // Calculate current available quantity
            $currentAvailableQty = $firstQuantity + $perchQuantity - $salesQuantity;
            
            // Check if requested quantity exceeds available quantity
            if ($item->quantity > $currentAvailableQty) {
                $insufficientItems[] = array(
                    'item_id' => $item->item_id,
                    'item_name' => $item_name,
                    'part_no' => $part_no,
                    'brand' => $brand,
                    'model' => $model,
                    'item_unit' => $item_unit,
                    'requested_quantity' => $item->quantity,
                    'available_quantity' => $currentAvailableQty,
                    'shortage' => $item->quantity - $currentAvailableQty,
                    'pay_price' => $pay_price,
                    'perch_price' => $perch_price
                );
            }
        } else {
            // Item not found in stock
            $insufficientItems[] = array(
                'item_id' => $item->item_id,
                'item_name' => 'Unknown Item',
                'part_no' => '',
                'brand' => '',
                'model' => '',
                'item_unit' => '',
                'requested_quantity' => $item->quantity,
                'available_quantity' => 0,
                'shortage' => $item->quantity,
                'pay_price' => 0,
                'perch_price' => 0
            );
        }
    }
    
    // Return validation results
    if (empty($insufficientItems)) {
        echo json_encode(array(
            'success' => true,
            'message' => 'All items have sufficient stock',
            'valid' => true,
            'insufficient_items' => array()
        ));
    } else {
        echo json_encode(array(
            'success' => true,
            'message' => 'Some items have insufficient stock',
            'valid' => false,
            'insufficient_items' => $insufficientItems
        ));
    }
    
} catch (Exception $e) {
    echo json_encode(array(
        'success' => false,
        'message' => 'Error validating stock quantities: ' . $e->getMessage()
    ));
}
?>