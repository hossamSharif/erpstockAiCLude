<?php 
  // Headers
  header('Access-Control-Allow-Origin: *');
  header('Content-Type: application/json');

  include_once '../../config/Database.php';
  include_once '../../models/items.php';

  // Instantiate DB & connect
  $database = new Database();
  $db = $database->connect();

  // Instantiate items object
  $items = new Items($db);

  // Get parameters
  $items->store_id = isset($_GET['store_id']) ? $_GET['store_id'] : die('{"message": "Missing store_id parameter"}');
  $items->yearId = isset($_GET['yearId']) ? $_GET['yearId'] : die('{"message": "Missing yearId parameter"}');
  
  try {
    // Get unique brands
    $result = $items->getUniqueBrands();
    
    $num = $result->rowCount();
    
    if($num > 0) {
      // Brands array
      $brands_arr = array();
      $brands_arr['data'] = array();

      while($row = $result->fetch(PDO::FETCH_ASSOC)) {
        extract($row);
        $brand_data = array( 
          'brand' => $brand,
          'count' => $brand_count
        );

        // Push to "data"
        array_push($brands_arr['data'], $brand_data);
      }

      // Turn to JSON & output
      echo json_encode($brands_arr);

    } else {
      // No brands found
      echo json_encode(array(
        'message' => 'No brands found',
        'data' => array()
      ));
    }
  } catch (Exception $e) {
    // Error occurred
    echo json_encode(array(
      'success' => false,
      'message' => 'Error retrieving brands: ' . $e->getMessage()
    ));
  }
?>