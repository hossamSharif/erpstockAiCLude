<?php
  header("Access-Control-Allow-Origin: *");
  header("Access-Control-Allow-Headers: access");
  header("Access-Control-Allow-Methods: GET");
  header("Content-Type: application/json; charset=UTF-8");
  header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

  require_once '../../config/Database.php';
  require_once '../../models/Purchase_returns.php';
  require_once '../../models/Purchase_return_details.php';

  $database = new Database();
  $db = $database->getConnection();

  $purchaseReturn = new Purchase_returns($db);
  $purchaseReturnDetails = new Purchase_return_details($db);

  $store_id = isset($_GET['store_id']) ? $_GET['store_id'] : null;
  $return_ref = isset($_GET['return_ref']) ? $_GET['return_ref'] : null;
  $yearId = isset($_GET['yearId']) ? $_GET['yearId'] : null;

  if (!$store_id || !$return_ref || !$yearId) {
      http_response_code(400);
      echo json_encode(array("message" => "Missing required parameters: store_id, return_ref, yearId"));
      exit();
  }

  try {
      // Get return invoice details
      $purchaseReturn->store_id = $store_id;
      $purchaseReturn->return_ref = $return_ref;
      $purchaseReturn->yearId = $yearId;
      
      $returnInvoice = $purchaseReturn->readByRef();
      
      if (!$returnInvoice) {
          http_response_code(404);
          echo json_encode(array("message" => "No record Found"));
          exit();
      }

      // Get return items details
      $purchaseReturnDetails->store_id = $store_id;
      $purchaseReturnDetails->return_ref = $return_ref;
      $purchaseReturnDetails->yearId = $yearId;
      
      $returnItemsStmt = $purchaseReturnDetails->readByStoreByRef();
      $returnItems = [];
      
      while ($row = $returnItemsStmt->fetch(PDO::FETCH_ASSOC)) {
          extract($row);
          $returnItem = array(
              "id" => $id,
              "return_ref" => $return_ref,
              "item_id" => $item_id,
              "item_name" => $item_name,
              "quantity" => $quantity,
              "return_price" => $return_price,
              "tot" => $tot,
              "store_id" => $store_id,
              "yearId" => $yearId,
              "dateCreated" => $dateCreated,
              "original_price" => $original_price,
              "tax" => $tax,
              "imageUrl" => $imageUrl
          );
          array_push($returnItems, $returnItem);
      }

      // Prepare response data
      $responseData = array(
          "returnInvoice" => $returnInvoice,
          "returnItems" => $returnItems
      );

      // Return successful response
      http_response_code(200);
      echo json_encode(array(
          "message" => "Purchase return details retrieved successfully",
          "data" => $responseData
      ));

  } catch (Exception $e) {
      http_response_code(500);
      echo json_encode(array(
          "message" => "Internal server error: " . $e->getMessage()
      ));
  }
?>