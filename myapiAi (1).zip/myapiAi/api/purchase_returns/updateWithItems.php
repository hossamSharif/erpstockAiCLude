<?php
  header("Access-Control-Allow-Origin: *");
  header("Access-Control-Allow-Headers: access");
  header("Access-Control-Allow-Methods: POST");
  header("Content-Type: application/json; charset=UTF-8");
  header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

  require_once '../../config/Database.php';
  require_once '../../models/Purchase_returns.php';
  require_once '../../models/Purchase_return_details.php';

  $database = new Database();
  $db = $database->getConnection();

  $purchaseReturn = new Purchase_returns($db);
  $purchaseReturnDetails = new Purchase_return_details($db);

  // Get raw posted data
  $data = json_decode(file_get_contents("php://input"));

  if (!$data || !isset($data->returnInvoice) || !isset($data->returnItems)) {
      http_response_code(400);
      echo json_encode(array("message" => "Missing required data: returnInvoice and returnItems"));
      exit();
  }

  try {
      // Begin transaction
      $db->beginTransaction();

      // Set purchase return properties from returnInvoice
      $returnInvoice = $data->returnInvoice;
      $purchaseReturn->return_ref = $returnInvoice->return_ref;
      $purchaseReturn->tot_pr = $returnInvoice->tot_pr;
      $purchaseReturn->return_date = $returnInvoice->return_date;
      $purchaseReturn->return_time = $returnInvoice->return_time;
      $purchaseReturn->supplier_id = $returnInvoice->supplier_id;
      $purchaseReturn->discount = $returnInvoice->discount;
      $purchaseReturn->changee = $returnInvoice->changee;
      $purchaseReturn->return_method = $returnInvoice->return_method;
      $purchaseReturn->returnComment = $returnInvoice->returnComment;
      $purchaseReturn->store_id = $returnInvoice->store_id;
      $purchaseReturn->yearId = $returnInvoice->yearId;
      $purchaseReturn->is_full_return = $returnInvoice->is_full_return;
      $purchaseReturn->return_reason = $returnInvoice->return_reason;

      // Update the purchase return
      if ($purchaseReturn->update()) {
          
          // Delete existing return items
          $purchaseReturnDetails->return_ref = $returnInvoice->return_ref;
          $purchaseReturnDetails->store_id = $returnInvoice->store_id;
          $purchaseReturnDetails->yearId = $returnInvoice->yearId;
          
          if (!$purchaseReturnDetails->deleteByReturnRef()) {
              throw new Exception("Failed to delete existing return items");
          }

          // Create new return items
          $itemsCreated = 0;
          foreach ($data->returnItems as $item) {
              $purchaseReturnDetails->return_ref = $returnInvoice->return_ref;
              $purchaseReturnDetails->item_name = $item->item_name;
              $purchaseReturnDetails->return_price = $item->return_price;
              $purchaseReturnDetails->quantity = $item->quantity;
              $purchaseReturnDetails->tot = $item->tot;
              $purchaseReturnDetails->store_id = $returnInvoice->store_id;
              $purchaseReturnDetails->item_id = $item->item_id;
              $purchaseReturnDetails->dateCreated = date('Y-m-d H:i:s');
              $purchaseReturnDetails->original_price = isset($item->original_price) ? $item->original_price : $item->return_price;
              $purchaseReturnDetails->yearId = $returnInvoice->yearId;
              $purchaseReturnDetails->tax = isset($item->tax) ? $item->tax : 0;
              $purchaseReturnDetails->imageUrl = isset($item->imageUrl) ? $item->imageUrl : '';

              if ($purchaseReturnDetails->create()) {
                  $itemsCreated++;
              } else {
                  throw new Exception("Failed to create return item: " . $item->item_name);
              }
          }

          // Commit transaction
          $db->commit();

          // Return success response
          http_response_code(200);
          echo json_encode(array(
              "message" => "Purchase return updated successfully",
              "return_ref" => $returnInvoice->return_ref,
              "items_updated" => $itemsCreated
          ));

      } else {
          throw new Exception("Failed to update purchase return");
      }

  } catch (Exception $e) {
      // Rollback transaction on error
      $db->rollBack();
      
      http_response_code(500);
      echo json_encode(array(
          "message" => "Failed to update purchase return: " . $e->getMessage()
      ));
  }
?>