# Item Analytics API Documentation

## Overview
The Analytics API provides comprehensive insights into item sales performance, customer behavior, and revenue trends for the ERP Stock Management System. All endpoints return JSON responses and support Cross-Origin Resource Sharing (CORS).

## Base URL
```
https://your-domain.com/myapi/api/analytics/
```

## Authentication
No authentication required for these endpoints. Access control should be implemented at the application level.

## Common Parameters

### Required Parameters (for most endpoints)
- `store_id` (integer): The store identifier
- `yearId` (integer): The fiscal year identifier

### Optional Parameters
- `start_date` (string): Start date filter in YYYY-MM-DD format
- `end_date` (string): End date filter in YYYY-MM-DD format
- `limit` (integer): Maximum number of results to return

## Endpoints

### 1. Get Item Sales Analytics
**Endpoint:** `getItemSalesAnalytics.php`

**Description:** Returns comprehensive sales analytics for all items with detailed performance metrics and summary statistics.

**Method:** GET

**Parameters:**
- `store_id` (required): Store identifier
- `yearId` (required): Fiscal year identifier
- `start_date` (optional): Start date filter
- `end_date` (optional): End date filter
- `limit` (optional): Result limit (default: 100)

**Example Request:**
```
GET /analytics/getItemSalesAnalytics.php?store_id=1&yearId=1&start_date=2024-01-01&end_date=2024-12-31&limit=50
```

**Response Structure:**
```json
{
  "data": [
    {
      "item_id": 1,
      "item_name": "Sample Item",
      "brand": "Brand Name",
      "model": "Model X",
      "part_no": "PN123",
      "total_quantity": 150.0,
      "total_revenue": 45000.0,
      "total_cost": 30000.0,
      "total_profit": 15000.0,
      "average_price": 300.0,
      "profit_margin": 33.33,
      "sales_count": 25,
      "last_sale_date": "2024-12-15",
      "first_sale_date": "2024-01-10",
      "avg_quantity_per_sale": 6.0
    }
  ],
  "summary": {
    "total_unique_items": 50,
    "total_items_sold": 2500.0,
    "total_revenue": 750000.0,
    "total_cost": 500000.0,
    "total_profit": 250000.0,
    "total_transactions": 500,
    "average_item_price": 300.0,
    "average_transaction_value": 1500.0,
    "overall_profit_margin": 33.33
  }
}
```

### 2. Get Top Selling Items by Quantity
**Endpoint:** `getTopSellingItemsByQuantity.php`

**Description:** Returns items ranked by total quantity sold, ideal for identifying fast-moving inventory.

**Method:** GET

**Parameters:**
- `store_id` (required): Store identifier
- `yearId` (required): Fiscal year identifier
- `start_date` (optional): Start date filter
- `end_date` (optional): End date filter
- `limit` (optional): Result limit (default: 50)

**Example Request:**
```
GET /analytics/getTopSellingItemsByQuantity.php?store_id=1&yearId=1&limit=10
```

**Response Structure:**
```json
{
  "data": [
    {
      "rank": 1,
      "item_id": 5,
      "item_name": "High Volume Item",
      "brand": "Popular Brand",
      "total_quantity": 500.0,
      "total_revenue": 125000.0,
      "sales_count": 45,
      "avg_quantity_per_sale": 11.11,
      "sales_frequency": 11.11
    }
  ]
}
```

### 3. Get Top Selling Items by Revenue
**Endpoint:** `getTopSellingItemsByRevenue.php`

**Description:** Returns items ranked by total revenue generated, perfect for identifying most profitable products.

**Method:** GET

**Parameters:**
- `store_id` (required): Store identifier
- `yearId` (required): Fiscal year identifier
- `start_date` (optional): Start date filter
- `end_date` (optional): End date filter
- `limit` (optional): Result limit (default: 50)

**Example Request:**
```
GET /analytics/getTopSellingItemsByRevenue.php?store_id=1&yearId=1&limit=10
```

**Response Structure:**
```json
{
  "data": [
    {
      "rank": 1,
      "item_id": 3,
      "item_name": "Premium Product",
      "total_revenue": 200000.0,
      "total_profit": 80000.0,
      "profit_margin": 40.0,
      "revenue_per_transaction": 4000.0,
      "price_range": 500.0
    }
  ]
}
```

### 4. Get Item Sales Trends
**Endpoint:** `getItemSalesTrends.php`

**Description:** Returns time-series sales data for a specific item, showing performance trends over time.

**Method:** GET

**Parameters:**
- `store_id` (required): Store identifier
- `yearId` (required): Fiscal year identifier
- `item_id` (required): Specific item identifier
- `start_date` (optional): Start date filter
- `end_date` (optional): End date filter
- `group_by` (optional): Grouping period - 'daily', 'weekly', or 'monthly' (default: 'monthly')

**Example Request:**
```
GET /analytics/getItemSalesTrends.php?store_id=1&yearId=1&item_id=5&group_by=monthly
```

**Response Structure:**
```json
{
  "data": [
    {
      "period": "2024-01",
      "period_start": "2024-01-05",
      "period_end": "2024-01-28",
      "quantity": 45.0,
      "revenue": 13500.0,
      "profit": 4500.0,
      "profit_margin": 33.33,
      "transaction_count": 8,
      "avg_quantity_per_transaction": 5.625
    }
  ],
  "summary": {
    "total_periods": 12,
    "total_quantity": 540.0,
    "total_revenue": 162000.0,
    "avg_quantity_per_period": 45.0,
    "highest_quantity_period": "2024-06"
  },
  "item_info": {
    "item_id": 5,
    "item_name": "Trending Item",
    "brand": "Brand X"
  }
}
```

### 5. Get Sales Summary Analytics
**Endpoint:** `getSalesSummaryAnalytics.php`

**Description:** Returns comprehensive sales performance overview including customer insights, payment methods, and daily trends.

**Method:** GET

**Parameters:**
- `store_id` (required): Store identifier
- `yearId` (required): Fiscal year identifier
- `start_date` (optional): Start date filter
- `end_date` (optional): End date filter

**Example Request:**
```
GET /analytics/getSalesSummaryAnalytics.php?store_id=1&yearId=1
```

**Response Structure:**
```json
{
  "summary": {
    "total_transactions": 1000,
    "unique_items_sold": 150,
    "total_revenue": 500000.0,
    "profit_margin_percentage": 35.0,
    "avg_transaction_value": 500.0
  },
  "top_customers": [
    {
      "customer_id": 45,
      "customer_name": "Top Customer",
      "total_spent": 25000.0,
      "transaction_count": 15
    }
  ],
  "payment_methods": [
    {
      "payment_method": "نقد",
      "transaction_count": 750,
      "total_revenue": 375000.0
    }
  ],
  "daily_trends": [
    {
      "date": "2024-12-15",
      "transactions": 25,
      "revenue": 12500.0
    }
  ],
  "brand_performance": [
    {
      "brand": "Top Brand",
      "total_revenue": 150000.0,
      "items_count": 25
    }
  ]
}
```

## Error Handling

### HTTP Status Codes
- `200 OK`: Request successful
- `400 Bad Request`: Missing required parameters
- `500 Internal Server Error`: Database or server error

### Error Response Format
```json
{
  "message": "Error description",
  "timestamp": "2024-12-15 10:30:00"
}
```

## Database Schema Dependencies

### Required Tables
- `pay` - Sales transactions
- `pay_details` - Sales line items
- `items` - Item master data
- `sub_accounts` - Customer accounts

### Key Relationships
- `pay.pay_ref` → `pay_details.pay_ref`
- `pay_details.item_id` → `items.id`
- `pay.cust_id` → `sub_accounts.id`

## Performance Considerations

1. **Indexing**: Ensure proper indexes on:
   - `pay_details.store_id, pay_details.yearId`
   - `pay.pay_date`
   - `pay_details.item_id`
   - `pay.cust_id`

2. **Query Limits**: Use the `limit` parameter to prevent large result sets

3. **Date Filtering**: Always use date filters for better performance with large datasets

4. **Caching**: Consider implementing response caching for frequently accessed data

## Usage Examples

### Frontend Integration (Angular/TypeScript)
```typescript
// Get comprehensive analytics
this.api.getItemSalesAnalytics(storeId, yearId, startDate, endDate)
  .subscribe(data => {
    this.analyticsData = data.data;
    this.summaryData = data.summary;
  });

// Get top selling items by quantity
this.api.getTopSellingItemsByQuantity(storeId, yearId, 10)
  .subscribe(data => {
    this.topQuantityItems = data.data;
  });
```

### Direct HTTP Calls
```bash
# Test API connectivity
curl "https://your-domain.com/myapi/api/analytics/test.php"

# Get sales analytics
curl "https://your-domain.com/myapi/api/analytics/getItemSalesAnalytics.php?store_id=1&yearId=1&limit=20"

# Get top revenue items with date filter
curl "https://your-domain.com/myapi/api/analytics/getTopSellingItemsByRevenue.php?store_id=1&yearId=1&start_date=2024-01-01&end_date=2024-12-31&limit=10"
```

## Security Notes

1. **Input Validation**: All endpoints validate required parameters
2. **SQL Injection Protection**: All queries use prepared statements
3. **Error Handling**: Database errors are caught and sanitized
4. **CORS**: Configured for cross-origin requests

## Support

For technical support or questions about the Analytics API, please contact the development team or refer to the main ERP system documentation.