<?php 
  // Headers
  header('Access-Control-Allow-Origin: *');
  header('Content-Type: application/json');

  include_once '../../config/Database.php';
  include_once '../../models/items.php';

  // Instantiate DB & connect
  $database = new Database();
  $db = $database->connect();

  // Instantiate items object
  $items = new Items($db);

  // Get parameters
  $items->store_id = isset($_GET['store_id']) ? $_GET['store_id'] : die('Store ID required');
  $items->id = isset($_GET['item_id']) ? $_GET['item_id'] : die('Item ID required');
  $yearId = isset($_GET['yearId']) ? $_GET['yearId'] : die('Year ID required');
  $startDate = isset($_GET['start_date']) ? $_GET['start_date'] : null;
  $endDate = isset($_GET['end_date']) ? $_GET['end_date'] : null;
  $reportType = isset($_GET['report_type']) ? intval($_GET['report_type']) : 0;

  try {
    // Get complete item report data
    $result = $items->getCompleteItemReport($reportType, $startDate, $endDate, $yearId);
    
    if($result) {
      // Return the complete data
      echo json_encode([
        'status' => 'success',
        'data' => $result
      ]);
    } else {
      echo json_encode([
        'status' => 'error',
        'message' => 'No data found for this item'
      ]);
    }
    
  } catch (Exception $e) {
    echo json_encode([
      'status' => 'error',
      'message' => 'Database error: ' . $e->getMessage()
    ]);
  }
?>