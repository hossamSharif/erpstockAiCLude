<?php
// Headers
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header('Access-Control-Allow-Methods: GET');
header('Access-Control-Allow-Headers: Access-Control-Allow-Headers, Content-Type, Access-Control-Allow-Methods, Authorization, X-Requested-With');

include_once '../../config/Database.php';

try {
    // Instantiate DB & connect
    $database = new Database();
    $db = $database->connect();

    // Get parameters
    $store_id = isset($_GET['store_id']) ? (int)$_GET['store_id'] : 0;
    $yearId = isset($_GET['yearId']) ? (int)$_GET['yearId'] : 0;
    $start_date = isset($_GET['start_date']) ? $_GET['start_date'] : '';
    $end_date = isset($_GET['end_date']) ? $_GET['end_date'] : '';

    // Validate required parameters
    if (!$store_id || !$yearId) {
        http_response_code(400);
        echo json_encode(array('message' => 'Missing required parameters: store_id and yearId'));
        exit;
    }

    // Build base WHERE clause
    $where_clause = 'WHERE p.store_id = :store_id AND p.yearId = :yearId';
    $date_params = array();

    if (!empty($start_date) && !empty($end_date)) {
        $where_clause .= ' AND p.pay_date BETWEEN :start_date AND :end_date';
        $date_params[':start_date'] = $start_date;
        $date_params[':end_date'] = $end_date;
    } elseif (!empty($start_date)) {
        $where_clause .= ' AND p.pay_date >= :start_date';
        $date_params[':start_date'] = $start_date;
    } elseif (!empty($end_date)) {
        $where_clause .= ' AND p.pay_date <= :end_date';
        $date_params[':end_date'] = $end_date;
    }

    // Query 1: Overall Summary
    $summary_query = '
        SELECT
            COUNT(DISTINCT p.pay_ref) as total_transactions,
            COUNT(DISTINCT pd.item_id) as unique_items_sold,
            SUM(pd.quantity) as total_quantity_sold,
            SUM(pd.quantity * pd.pay_price) as total_revenue,
            SUM(pd.quantity * pd.perch_price) as total_cost,
            SUM(pd.quantity * (pd.pay_price - pd.perch_price)) as total_profit,
            AVG(pd.pay_price) as avg_item_price,
            AVG(p.tot_pr) as avg_transaction_value,
            MAX(p.tot_pr) as highest_transaction,
            MIN(p.tot_pr) as lowest_transaction,
            AVG(pd.quantity) as avg_quantity_per_item
        FROM pay p
        INNER JOIN pay_details pd ON p.pay_ref = pd.pay_ref AND p.store_id = pd.store_id AND p.yearId = pd.yearId
        ' . $where_clause;

    $stmt = $db->prepare($summary_query);
    $stmt->bindParam(':store_id', $store_id, PDO::PARAM_INT);
    $stmt->bindParam(':yearId', $yearId, PDO::PARAM_INT);
    foreach ($date_params as $key => $value) {
        $stmt->bindParam($key, $value);
    }
    $stmt->execute();
    $summary = $stmt->fetch(PDO::FETCH_ASSOC);

    // Query 2: Top 5 Customers by Revenue
    $top_customers_query = '
        SELECT
            p.cust_id,
            s.sub_name as customer_name,
            COUNT(DISTINCT p.pay_ref) as transaction_count,
            SUM(p.tot_pr) as total_spent,
            AVG(p.tot_pr) as avg_transaction_value,
            MAX(p.pay_date) as last_purchase_date
        FROM pay p
        LEFT JOIN sub_accounts s ON p.cust_id = s.id AND p.store_id = s.store_id
        ' . $where_clause . '
        GROUP BY p.cust_id, s.sub_name
        ORDER BY total_spent DESC
        LIMIT 5';

    $stmt = $db->prepare($top_customers_query);
    $stmt->bindParam(':store_id', $store_id, PDO::PARAM_INT);
    $stmt->bindParam(':yearId', $yearId, PDO::PARAM_INT);
    foreach ($date_params as $key => $value) {
        $stmt->bindParam($key, $value);
    }
    $stmt->execute();
    $top_customers = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Query 3: Sales by Payment Method
    $payment_methods_query = '
        SELECT
            p.pay_method,
            COUNT(*) as transaction_count,
            SUM(p.tot_pr) as total_revenue,
            AVG(p.tot_pr) as avg_transaction_value
        FROM pay p
        ' . $where_clause . '
        GROUP BY p.pay_method
        ORDER BY total_revenue DESC';

    $stmt = $db->prepare($payment_methods_query);
    $stmt->bindParam(':store_id', $store_id, PDO::PARAM_INT);
    $stmt->bindParam(':yearId', $yearId, PDO::PARAM_INT);
    foreach ($date_params as $key => $value) {
        $stmt->bindParam($key, $value);
    }
    $stmt->execute();
    $payment_methods = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Query 4: Daily Sales Trend (last 30 days or date range)
    $trend_query = '
        SELECT
            DATE(p.pay_date) as sale_date,
            COUNT(DISTINCT p.pay_ref) as daily_transactions,
            SUM(p.tot_pr) as daily_revenue,
            SUM(pd.quantity) as daily_quantity,
            AVG(p.tot_pr) as avg_daily_transaction
        FROM pay p
        INNER JOIN pay_details pd ON p.pay_ref = pd.pay_ref AND p.store_id = pd.store_id AND p.yearId = pd.yearId
        ' . $where_clause . '
        GROUP BY DATE(p.pay_date)
        ORDER BY sale_date DESC
        LIMIT 30';

    $stmt = $db->prepare($trend_query);
    $stmt->bindParam(':store_id', $store_id, PDO::PARAM_INT);
    $stmt->bindParam(':yearId', $yearId, PDO::PARAM_INT);
    foreach ($date_params as $key => $value) {
        $stmt->bindParam($key, $value);
    }
    $stmt->execute();
    $daily_trends = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Query 5: Top Categories/Brands Performance
    $category_performance_query = '
        SELECT
            COALESCE(i.brand, "غير محدد") as brand,
            COUNT(DISTINCT pd.item_id) as items_count,
            SUM(pd.quantity) as total_quantity,
            SUM(pd.quantity * pd.pay_price) as total_revenue,
            AVG(pd.pay_price) as avg_price
        FROM pay_details pd
        INNER JOIN pay p ON pd.pay_ref = p.pay_ref AND pd.store_id = p.store_id AND pd.yearId = p.yearId
        LEFT JOIN items i ON pd.item_id = i.id
        ' . $where_clause . '
        GROUP BY i.brand
        ORDER BY total_revenue DESC
        LIMIT 10';

    $stmt = $db->prepare($category_performance_query);
    $stmt->bindParam(':store_id', $store_id, PDO::PARAM_INT);
    $stmt->bindParam(':yearId', $yearId, PDO::PARAM_INT);
    foreach ($date_params as $key => $value) {
        $stmt->bindParam($key, $value);
    }
    $stmt->execute();
    $brand_performance = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Calculate additional metrics
    $profit_margin = $summary['total_revenue'] > 0 ?
        (($summary['total_profit'] / $summary['total_revenue']) * 100) : 0;

    $items_per_transaction = $summary['total_transactions'] > 0 ?
        ($summary['unique_items_sold'] / $summary['total_transactions']) : 0;

    // Prepare response
    $analytics_response = array(
        'summary' => array(
            'total_transactions' => (int)$summary['total_transactions'],
            'unique_items_sold' => (int)$summary['unique_items_sold'],
            'total_quantity_sold' => (float)$summary['total_quantity_sold'],
            'total_revenue' => (float)$summary['total_revenue'],
            'total_cost' => (float)$summary['total_cost'],
            'total_profit' => (float)$summary['total_profit'],
            'profit_margin_percentage' => (float)$profit_margin,
            'avg_item_price' => (float)$summary['avg_item_price'],
            'avg_transaction_value' => (float)$summary['avg_transaction_value'],
            'highest_transaction' => (float)$summary['highest_transaction'],
            'lowest_transaction' => (float)$summary['lowest_transaction'],
            'avg_quantity_per_item' => (float)$summary['avg_quantity_per_item'],
            'avg_items_per_transaction' => (float)$items_per_transaction
        ),
        'top_customers' => array_map(function($customer) {
            return array(
                'customer_id' => (int)$customer['cust_id'],
                'customer_name' => $customer['customer_name'] ?: 'عميل غير معروف',
                'transaction_count' => (int)$customer['transaction_count'],
                'total_spent' => (float)$customer['total_spent'],
                'avg_transaction_value' => (float)$customer['avg_transaction_value'],
                'last_purchase_date' => $customer['last_purchase_date']
            );
        }, $top_customers),
        'payment_methods' => array_map(function($method) {
            return array(
                'payment_method' => $method['pay_method'] ?: 'غير محدد',
                'transaction_count' => (int)$method['transaction_count'],
                'total_revenue' => (float)$method['total_revenue'],
                'avg_transaction_value' => (float)$method['avg_transaction_value']
            );
        }, $payment_methods),
        'daily_trends' => array_map(function($trend) {
            return array(
                'date' => $trend['sale_date'],
                'transactions' => (int)$trend['daily_transactions'],
                'revenue' => (float)$trend['daily_revenue'],
                'quantity' => (float)$trend['daily_quantity'],
                'avg_transaction' => (float)$trend['avg_daily_transaction']
            );
        }, array_reverse($daily_trends)), // Reverse to show chronological order
        'brand_performance' => array_map(function($brand) {
            return array(
                'brand' => $brand['brand'],
                'items_count' => (int)$brand['items_count'],
                'total_quantity' => (float)$brand['total_quantity'],
                'total_revenue' => (float)$brand['total_revenue'],
                'avg_price' => (float)$brand['avg_price']
            );
        }, $brand_performance),
        'filters_applied' => array(
            'store_id' => $store_id,
            'yearId' => $yearId,
            'start_date' => $start_date,
            'end_date' => $end_date
        ),
        'generated_at' => date('Y-m-d H:i:s')
    );

    // Return JSON response
    echo json_encode($analytics_response);

} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(array('message' => 'Database error: ' . $e->getMessage()));
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(array('message' => 'Server error: ' . $e->getMessage()));
}
?>