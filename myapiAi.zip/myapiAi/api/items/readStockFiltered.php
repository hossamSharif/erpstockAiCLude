<?php 
  // Headers
  header('Access-Control-Allow-Origin: *');
  header('Content-Type: application/json');

  include_once '../../config/Database.php';
  include_once '../../models/items.php';

  // Instantiate DB & connect
  $database = new Database();
  $db = $database->connect();

  // Instantiate items object
  $items = new Items($db);

  // Get parameters
  $items->store_id = isset($_GET['store_id']) ? $_GET['store_id'] : die();
  $items->yearId = isset($_GET['yearId']) ? $_GET['yearId'] : die();
  
  // Get filter parameters (no search)
  $brand = isset($_GET['brand']) ? $_GET['brand'] : '';
  $model = isset($_GET['model']) ? $_GET['model'] : '';
  $quantity_filter = isset($_GET['quantity_filter']) ? $_GET['quantity_filter'] : '';
  $category_id = isset($_GET['category_id']) ? $_GET['category_id'] : 'all';

  // Get filtered items
  $result = $items->getFilteredItems($brand, $model, $quantity_filter, $category_id);
   
  $num = $result->rowCount();
  
  if($num > 0) {
    // Items array
    $items_arr = array();
    $items_arr['data'] = array();

    while($row = $result->fetch(PDO::FETCH_ASSOC)) {
      extract($row);
      $item = array( 
        'id' => $id,
        'item_name' => $item_name,
        'part_no' => $part_no,
        'model' => $model,
        'brand' => $brand,
        'min_qty' => $min_qty,
        'item_unit' => $item_unit,
        'pay_price' => $pay_price, 
        'perch_price' => $perch_price,
        'item_desc' => $item_desc,
        'item_parcode' => $item_parcode,
        'salesQuantity' => $salesQuantity,
        'perchQuantity' => $perchQuantity,
        'firstQuantity' => $firstQuantity,
        'lastSoldDate' => $lastSoldDate,
        'lastSoldQty' => $lastSoldQty,
        'aliasEn' => $aliasEn,
        'tswiaQuantity' => $tswiaQuantity,
        'quantity' => $quantity,
        'stockValuePayPrice' => $stockValuePayPrice,
        'stockValuePerchPrice' => $stockValuePerchPrice
      );

      // Push to "data"
      array_push($items_arr['data'], $item);
    }

    // Turn to JSON & output
    echo json_encode($items_arr);

  } else {
    // No items
    echo json_encode(array('message' => 'No items Found'));
  }
?>