<?php
// Headers
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header('Access-Control-Allow-Methods: GET');
header('Access-Control-Allow-Headers: Access-Control-Allow-Headers, Content-Type, Access-Control-Allow-Methods, Authorization, X-Requested-With');

include_once '../../config/Database.php';

try {
    // Instantiate DB & connect
    $database = new Database();
    $db = $database->connect();

    $response = array(
        'message' => 'Analytics API is working successfully!',
        'timestamp' => date('Y-m-d H:i:s'),
        'database_status' => 'Connected',
        'available_endpoints' => array(
            'getItemSalesAnalytics.php' => 'Comprehensive item sales analytics with summary data',
            'getTopSellingItemsByQuantity.php' => 'Top selling items ranked by quantity sold',
            'getTopSellingItemsByRevenue.php' => 'Top selling items ranked by revenue generated',
            'getItemSalesTrends.php' => 'Sales trends for specific items over time',
            'getSalesSummaryAnalytics.php' => 'Overall sales performance summary with customer insights'
        ),
        'required_parameters' => array(
            'store_id' => 'Required for all endpoints - the store identifier',
            'yearId' => 'Required for all endpoints - the fiscal year identifier',
            'start_date' => 'Optional date filter in YYYY-MM-DD format',
            'end_date' => 'Optional date filter in YYYY-MM-DD format',
            'limit' => 'Optional limit for result count (default: 50-100 depending on endpoint)',
            'item_id' => 'Required for getItemSalesTrends.php - specific item identifier'
        ),
        'example_usage' => array(
            'getItemSalesAnalytics.php?store_id=1&yearId=1',
            'getTopSellingItemsByQuantity.php?store_id=1&yearId=1&limit=10',
            'getTopSellingItemsByRevenue.php?store_id=1&yearId=1&start_date=2024-01-01&end_date=2024-12-31',
            'getItemSalesTrends.php?store_id=1&yearId=1&item_id=5&group_by=monthly',
            'getSalesSummaryAnalytics.php?store_id=1&yearId=1'
        )
    );

    echo json_encode($response, JSON_PRETTY_PRINT);

} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(array(
        'message' => 'Database connection failed',
        'error' => $e->getMessage(),
        'timestamp' => date('Y-m-d H:i:s')
    ));
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(array(
        'message' => 'Server error',
        'error' => $e->getMessage(),
        'timestamp' => date('Y-m-d H:i:s')
    ));
}
?>