<?php
  // Headers
  header('Access-Control-Allow-Origin: *');
  header('Content-Type: application/json');
  header('Access-Control-Allow-Methods: POST');
  header('Access-Control-Allow-Headers: Access-Control-Allow-Headers,Content-Type,Access-Control-Allow-Methods, Authorization, X-Requested-With');

  // Handle preflight OPTIONS request
  if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
      http_response_code(200);
      exit();
  }

include_once '../../config/Database.php';
include_once '../../models/perch.php';
include_once '../../models/perch_details.php';
include_once '../../models/perchOrder.php';
include_once '../../models/perchOrder_details.php';

// Get database connection
$database = new Database();
$db = $database->connect();

// Initialize models
$perch = new Perch($db);
$perch_details = new Perch_details($db);
$perchOrder = new PerchOrder($db);
$perchOrder_details = new PerchOrder_details($db);

// Get posted data
$raw_input = file_get_contents("php://input");
$data = json_decode($raw_input, true);

if (!$data) {
    http_response_code(400);
    echo json_encode(['message' => 'Invalid JSON data']);
    exit;
}

// Start transaction
$db->beginTransaction();

try {
    // Validate required data
    if (!isset($data['pay_id']) || !isset($data['pay_ref']) || !isset($data['store_id']) || !isset($data['yearId'])) {
        throw new Exception('Missing required fields: pay_id, pay_ref, store_id, yearId');
    }

    // Step 1: Get purchase invoice items
    $perch_details->store_id = $data['store_id'];
    $perch_details->pay_ref = $data['pay_ref'];
    $perch_details->yearId = $data['yearId'];
    $itemsResult = $perch_details->readByStoreByRef();

    $items = [];
    while($row = $itemsResult->fetch(PDO::FETCH_ASSOC)) {
        $items[] = $row;
    }

    if (empty($items)) {
        throw new Exception('No items found for this purchase invoice');
    }

    // Step 2: Create purchase order with same data
    $perchOrder->pay_ref = $data['pay_ref'];
    $perchOrder->tot_pr = $data['tot_pr'];
    $perchOrder->pay = $data['pay'];
    $perchOrder->changee = $data['changee'];
    $perchOrder->user_id = $data['user_id'];
    $perchOrder->store_id = $data['store_id'];
    $perchOrder->pay_date = $data['pay_date'];
    $perchOrder->pay_time = $data['pay_time'];
    $perchOrder->nextPay = $data['nextPay'];
    $perchOrder->discount = $data['discount'];
    $perchOrder->payComment = $data['payComment'];
    $perchOrder->cust_id = $data['cust_id'];
    $perchOrder->pay_method = $data['pay_method'];
    $perchOrder->yearId = $data['yearId'];

    if (!$perchOrder->create()) {
        throw new Exception('Unable to create purchase order');
    }

    // Step 3: Create order items
    $itemsCreated = 0;
    foreach ($items as $item) {
        $perchOrder_details->pay_ref = $data['pay_ref'];
        $perchOrder_details->item_id = $item['item_id'];
        $perchOrder_details->item_name = $item['item_name'];
        $perchOrder_details->pay_price = $item['pay_price'];
        $perchOrder_details->quantity = $item['quantity'];
        $perchOrder_details->tot = $item['tot'];
        $perchOrder_details->store_id = $data['store_id'];
        $perchOrder_details->dateCreated = $item['dateCreated'];
        $perchOrder_details->perch_price = $item['perch_price'];
        $perchOrder_details->yearId = $data['yearId'];

        if ($perchOrder_details->create()) {
            $itemsCreated++;
        } else {
            throw new Exception('Unable to create order item: ' . $item['item_name']);
        }
    }

    // Step 4: Delete purchase invoice items
    $perch_details->pay_ref = $data['pay_ref'];
    if (!$perch_details->deleteMultiServices()) {
        throw new Exception('Unable to delete purchase invoice items');
    }

    // Step 5: Delete purchase invoice
    $perch->pay_id = $data['pay_id'];
    if (!$perch->delete()) {
        throw new Exception('Unable to delete purchase invoice');
    }

    // Commit transaction
    $db->commit();

    // Return success response
    http_response_code(200);
    echo json_encode([
        'message' => 'Purchase invoice converted to order successfully',
        'items_converted' => $itemsCreated,
        'success' => true
    ]);

} catch (Exception $e) {
    // Rollback transaction on error
    $db->rollback();

    http_response_code(400);
    echo json_encode([
        'message' => 'Failed to convert purchase invoice: ' . $e->getMessage(),
        'success' => false
    ]);
}
?>
