<?php
// Headers
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header('Access-Control-Allow-Methods: GET');
header('Access-Control-Allow-Headers: Access-Control-Allow-Headers, Content-Type, Access-Control-Allow-Methods, Authorization, X-Requested-With');

include_once '../../config/Database.php';

try {
    // Instantiate DB & connect
    $database = new Database();
    $db = $database->connect();

    // Get parameters
    $store_id = isset($_GET['store_id']) ? (int)$_GET['store_id'] : 0;
    $yearId = isset($_GET['yearId']) ? (int)$_GET['yearId'] : 0;
    $start_date = isset($_GET['start_date']) ? $_GET['start_date'] : '';
    $end_date = isset($_GET['end_date']) ? $_GET['end_date'] : '';
    $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 1000; // Increased default limit

    // Validate required parameters
    if (!$store_id || !$yearId) {
        http_response_code(400);
        echo json_encode(array('message' => 'Missing required parameters: store_id and yearId'));
        exit;
    }

    // Build the query
    $query = '
        SELECT
            pd.item_id,
            pd.item_name,
            i.brand,
            i.model,
            i.part_no,
            SUM(pd.quantity) as total_quantity,
            SUM(pd.quantity * pd.pay_price) as total_revenue,
            AVG(pd.pay_price) as average_price,
            COUNT(DISTINCT pd.pay_ref) as sales_count,
            MAX(p.pay_date) as last_sale_date,
            MIN(p.pay_date) as first_sale_date,
            SUM(pd.quantity * pd.perch_price) as total_cost,
            SUM(pd.quantity * (pd.pay_price - pd.perch_price)) as total_profit
        FROM pay_details pd
        INNER JOIN pay p ON pd.pay_ref = p.pay_ref AND pd.store_id = p.store_id AND pd.yearId = p.yearId
        LEFT JOIN items i ON pd.item_id = i.id
        WHERE pd.store_id = :store_id
        AND pd.yearId = :yearId
    ';

    // Add date filters if provided
    if (!empty($start_date) && !empty($end_date)) {
        $query .= ' AND p.pay_date BETWEEN :start_date AND :end_date';
    } elseif (!empty($start_date)) {
        $query .= ' AND p.pay_date >= :start_date';
    } elseif (!empty($end_date)) {
        $query .= ' AND p.pay_date <= :end_date';
    }

    $query .= '
        GROUP BY pd.item_id, pd.item_name, i.brand, i.model, i.part_no
        HAVING total_quantity > 0
        ORDER BY total_revenue DESC, total_quantity DESC
    ';

    // Only add LIMIT if a specific limit was requested
    if (isset($_GET['limit'])) {
        $query .= ' LIMIT :limit';
    }

    // Prepare statement
    $stmt = $db->prepare($query);

    // Bind parameters
    $stmt->bindParam(':store_id', $store_id, PDO::PARAM_INT);
    $stmt->bindParam(':yearId', $yearId, PDO::PARAM_INT);

    // Only bind limit if it was requested
    if (isset($_GET['limit'])) {
        $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
    }

    if (!empty($start_date) && !empty($end_date)) {
        $stmt->bindParam(':start_date', $start_date);
        $stmt->bindParam(':end_date', $end_date);
    } elseif (!empty($start_date)) {
        $stmt->bindParam(':start_date', $start_date);
    } elseif (!empty($end_date)) {
        $stmt->bindParam(':end_date', $end_date);
    }

    // Execute query
    $stmt->execute();
    $num = $stmt->rowCount();

    if ($num > 0) {
        // Analytics array
        $analytics_arr = array();
        $analytics_arr['data'] = array();
        $analytics_arr['summary'] = array();

        // Initialize summary totals
        $summary_totals = [
            'total_unique_items' => 0,
            'total_items_sold' => 0,
            'total_revenue' => 0,
            'total_cost' => 0,
            'total_profit' => 0,
            'total_transactions' => 0
        ];

        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            extract($row);

            // Calculate profit margin percentage
            $profit_margin = $total_revenue > 0 ? (($total_profit / $total_revenue) * 100) : 0;

            $analytics_item = array(
                'item_id' => (int)$item_id,
                'item_name' => $item_name ?: 'Unknown Item',
                'brand' => $brand ?: '',
                'model' => $model ?: '',
                'part_no' => $part_no ?: '',
                'total_quantity' => (float)$total_quantity,
                'total_revenue' => (float)$total_revenue,
                'total_cost' => (float)$total_cost,
                'total_profit' => (float)$total_profit,
                'average_price' => (float)$average_price,
                'profit_margin' => (float)$profit_margin,
                'sales_count' => (int)$sales_count,
                'last_sale_date' => $last_sale_date,
                'first_sale_date' => $first_sale_date,
                'avg_quantity_per_sale' => $sales_count > 0 ? (float)($total_quantity / $sales_count) : 0
            );

            // Update summary totals
            $summary_totals['total_unique_items']++;
            $summary_totals['total_items_sold'] += (float)$total_quantity;
            $summary_totals['total_revenue'] += (float)$total_revenue;
            $summary_totals['total_cost'] += (float)$total_cost;
            $summary_totals['total_profit'] += (float)$total_profit;
            $summary_totals['total_transactions'] += (int)$sales_count;

            array_push($analytics_arr['data'], $analytics_item);
        }

        // Add calculated summary metrics
        $summary_totals['average_item_price'] = $summary_totals['total_items_sold'] > 0 ?
            ($summary_totals['total_revenue'] / $summary_totals['total_items_sold']) : 0;
        $summary_totals['average_transaction_value'] = $summary_totals['total_transactions'] > 0 ?
            ($summary_totals['total_revenue'] / $summary_totals['total_transactions']) : 0;
        $summary_totals['overall_profit_margin'] = $summary_totals['total_revenue'] > 0 ?
            (($summary_totals['total_profit'] / $summary_totals['total_revenue']) * 100) : 0;

        $analytics_arr['summary'] = $summary_totals;
        $analytics_arr['filters_applied'] = array(
            'store_id' => $store_id,
            'yearId' => $yearId,
            'start_date' => $start_date,
            'end_date' => $end_date,
            'limit' => $limit
        );

        // Return JSON response
        echo json_encode($analytics_arr);

    } else {
        // No data found
        echo json_encode(array(
            'message' => 'No record Found',
            'data' => array(),
            'summary' => array(
                'total_unique_items' => 0,
                'total_items_sold' => 0,
                'total_revenue' => 0,
                'total_cost' => 0,
                'total_profit' => 0,
                'total_transactions' => 0,
                'average_item_price' => 0,
                'average_transaction_value' => 0,
                'overall_profit_margin' => 0
            )
        ));
    }

} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(array('message' => 'Database error: ' . $e->getMessage()));
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(array('message' => 'Server error: ' . $e->getMessage()));
}
?>