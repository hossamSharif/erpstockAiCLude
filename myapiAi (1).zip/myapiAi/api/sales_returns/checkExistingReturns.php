<?php 
  // Headers
  header('Access-Control-Allow-Origin: *');
  header('Content-Type: application/json');
  header('Access-Control-Allow-Methods: GET');
  header('Access-Control-Allow-Headers: Access-Control-Allow-Headers,Content-Type,Access-Control-Allow-Methods, Authorization, X-Requested-With');

  include_once '../../config/Database.php';
  include_once '../../models/Sales_returns.php';
  include_once '../../models/Sales_return_details.php';

  // Instantiate DB & connect
  $database = new Database();
  $db = $database->connect();

  // Instantiate objects
  $return_invoice = new Sales_returns($db);
  $return_details = new Sales_return_details($db);

  // Get the original invoice reference
  $original_pay_ref = isset($_GET['original_pay_ref']) ? $_GET['original_pay_ref'] : '';
  $store_id = isset($_GET['store_id']) ? $_GET['store_id'] : '';
  $yearId = isset($_GET['yearId']) ? $_GET['yearId'] : '';

  if (empty($original_pay_ref)) {
    echo json_encode(
      array('success' => false, 'message' => 'Missing required parameter: original_pay_ref')
    );
    exit();
  }

  try {
    // Check for existing returns for this invoice
    $query = "SELECT sr.*, GROUP_CONCAT(srd.item_name) as returned_items,
              SUM(srd.quantity) as total_returned_quantity,
              COUNT(srd.id) as returned_items_count
              FROM sales_returns sr 
              LEFT JOIN sales_return_details srd ON sr.return_ref = srd.return_ref 
              WHERE sr.original_pay_ref = :original_pay_ref";
    
    if (!empty($store_id)) {
      $query .= " AND sr.store_id = :store_id";
    }
    
    if (!empty($yearId)) {
      $query .= " AND sr.yearId = :yearId";
    }
    
    $query .= " GROUP BY sr.return_id ORDER BY sr.return_date DESC";

    $stmt = $db->prepare($query);
    $stmt->bindParam(':original_pay_ref', $original_pay_ref);
    
    if (!empty($store_id)) {
      $stmt->bindParam(':store_id', $store_id);
    }
    
    if (!empty($yearId)) {
      $stmt->bindParam(':yearId', $yearId);
    }
    
    $stmt->execute();
    $existing_returns = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (count($existing_returns) > 0) {
      // Calculate summary information
      $total_returned_amount = 0;
      $has_full_return = false;
      $returned_items_summary = [];

      foreach ($existing_returns as $return) {
        $total_returned_amount += $return['tot_pr'];
        if ($return['is_full_return'] == 1) {
          $has_full_return = true;
        }
        
        if ($return['returned_items']) {
          $items = explode(',', $return['returned_items']);
          foreach ($items as $item) {
            if (!in_array($item, $returned_items_summary)) {
              $returned_items_summary[] = $item;
            }
          }
        }
      }

      echo json_encode(array(
        'success' => true,
        'has_existing_returns' => true,
        'returns_count' => count($existing_returns),
        'total_returned_amount' => $total_returned_amount,
        'has_full_return' => $has_full_return,
        'returned_items_summary' => $returned_items_summary,
        'existing_returns' => $existing_returns,
        'message' => 'Found existing returns for this invoice'
      ));
    } else {
      echo json_encode(array(
        'success' => true,
        'has_existing_returns' => false,
        'returns_count' => 0,
        'message' => 'No existing returns found for this invoice'
      ));
    }

  } catch (Exception $e) {
    echo json_encode(array(
      'success' => false,
      'message' => 'Error checking existing returns: ' . $e->getMessage()
    ));
  }
?>