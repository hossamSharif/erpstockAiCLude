<?php
header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Headers: X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Access-Control-Request-Method");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");
header("Allow: GET, POST, OPTIONS, PUT, DELETE");
header("Content-Type: application/json; charset=UTF-8");

$method = $_SERVER['REQUEST_METHOD'];
if($method == "OPTIONS") {
    die();
}

include_once '../../config/Database.php';

$database = new Database();
$db = $database->connect();

// Get parameters
$store_id = isset($_GET['store_id']) ? $_GET['store_id'] : die('{"success": false, "message": "Missing store_id parameter"}');
$year_id = isset($_GET['year_id']) ? $_GET['year_id'] : die('{"success": false, "message": "Missing year_id parameter"}');

try {
    // Get accounts with cat_id 1 (customers/debtors) and cat_id 2 (suppliers/creditors)
    $accounts_stmt = $db->prepare("
        SELECT 
            sa.id,
            sa.ac_id,
            sa.sub_name,
            sa.sub_type,
            sa.sub_balance,
            sa.cat_id,
            sa.cat_name
        FROM sub_accounts sa
        WHERE sa.store_id = ? AND (sa.cat_id = 1 OR sa.cat_id = 2)
        ORDER BY sa.cat_id, sa.sub_name
    ");
    $accounts_stmt->execute([$store_id]);
    $accounts = $accounts_stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $total_debtors = 0;
    $total_creditors = 0;
    $debtors_count = 0;
    $creditors_count = 0;
    
    foreach ($accounts as $account) {
        $account_id = $account['id'];
        $opening_balance = floatval($account['sub_balance']);
        
        // Get journal entries for this account
        $journal_from_stmt = $db->prepare("
            SELECT COALESCE(SUM(debit), 0) as total_debit, COALESCE(SUM(credit), 0) as total_credit
            FROM jdetails_from jf
            JOIN journal j ON jf.j_ref = j.j_ref
            WHERE jf.ac_id = ? AND j.store_id = ? AND j.yearId = ?
        ");
        $journal_from_stmt->execute([$account_id, $store_id, $year_id]);
        $from_result = $journal_from_stmt->fetch(PDO::FETCH_ASSOC);
        
        $journal_to_stmt = $db->prepare("
            SELECT COALESCE(SUM(debit), 0) as total_debit, COALESCE(SUM(credit), 0) as total_credit
            FROM jdetails_to jt
            JOIN journal j ON jt.j_ref = j.j_ref
            WHERE jt.ac_id = ? AND j.store_id = ? AND j.yearId = ?
        ");
        $journal_to_stmt->execute([$account_id, $store_id, $year_id]);
        $to_result = $journal_to_stmt->fetch(PDO::FETCH_ASSOC);
        
        $total_debits = floatval($from_result['total_debit']) + floatval($to_result['total_debit']);
        $total_credits = floatval($from_result['total_credit']) + floatval($to_result['total_credit']);
        
        // Get outstanding balances from pay and perch tables
        if ($account['cat_id'] == 1 || $account['cat_id'] == 2) {
            // Sales changee amounts (goes to debit side)
            $sales_stmt = $db->prepare("
                SELECT COALESCE(SUM(changee), 0) as sales_changee_amount
                FROM pay 
                WHERE cust_id = ? AND store_id = ? AND yearId = ?
            ");
            $sales_stmt->execute([$account_id, $store_id, $year_id]);
            $sales_result = $sales_stmt->fetch(PDO::FETCH_ASSOC);
            $sales_total = floatval($sales_result['sales_changee_amount']);
            
            // Purchase changee amounts (goes to credit side)
            $purchases_stmt = $db->prepare("
                SELECT COALESCE(SUM(changee), 0) as purchases_changee_amount
                FROM perch 
                WHERE cust_id = ? AND store_id = ? AND yearId = ?
            ");
            $purchases_stmt->execute([$account_id, $store_id, $year_id]);
            $purchases_result = $purchases_stmt->fetch(PDO::FETCH_ASSOC);
            $purchases_total = floatval($purchases_result['purchases_changee_amount']);
            
            $total_debits += $sales_total;
            $total_credits += $purchases_total;
        }
        
        // Calculate current balance based on account type
        $current_balance = 0;
        
        if ($account['sub_type'] == 'مدين') {
            // Debit accounts: increase with debits, decrease with credits
            $current_balance = $opening_balance + $total_debits - $total_credits;
        } else {
            // Credit accounts: increase with credits, decrease with debits
            $current_balance = $opening_balance + $total_credits - $total_debits;
        }
        
        // Only include accounts with positive balances
        if ($current_balance > 0) {
            if ($account['cat_id'] == 1) {
                // Customer/Debtor (cat_id = 1)
                $total_debtors += $current_balance;
                $debtors_count++;
            } elseif ($account['cat_id'] == 2) {
                // Supplier/Creditor (cat_id = 2)
                $total_creditors += $current_balance;
                $creditors_count++;
            }
        }
    }
    
    $response = array(
        "success" => true,
        "data" => array(
            "total_debtors" => $total_debtors,
            "total_creditors" => $total_creditors,
            "debtors_count" => $debtors_count,
            "creditors_count" => $creditors_count,
            "net_position" => $total_debtors - $total_creditors
        ),
        "message" => "Debtor and creditor totals retrieved successfully"
    );

    http_response_code(200);
    echo json_encode($response);

} catch(Exception $e) {
    http_response_code(500);
    echo json_encode(array(
        "success" => false,
        "message" => "Error retrieving debtor and creditor data",
        "error" => $e->getMessage()
    ));
}
?>