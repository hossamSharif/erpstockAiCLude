<?php 
  // Headers
  header('Access-Control-Allow-Origin: *');
  header('Content-Type: application/json');
  header('Access-Control-Allow-Methods: PUT');
  header('Access-Control-Allow-Headers: Access-Control-Allow-Headers,Content-Type,Access-Control-Allow-Methods, Authorization, X-Requested-With');

  include_once '../../config/Database.php';
  include_once '../../models/Sales_returns.php';
  include_once '../../models/Sales_return_details.php';

  // Instantiate DB & connect
  $database = new Database();
  $db = $database->connect();

  // Instantiate objects
  $return_invoice = new Sales_returns($db);
  $return_details = new Sales_return_details($db);

  // Get raw posted data
  $data = json_decode(file_get_contents("php://input"));

  if (!$data || !isset($data->invoice) || !isset($data->items)) {
    echo json_encode(
      array('success' => false, 'message' => 'Missing required data: invoice and items')
    );
    exit();
  }

  $invoice_data = $data->invoice;
  $items_data = $data->items;

  // Validate required invoice fields
  if (!isset($invoice_data->return_id) || !isset($invoice_data->return_ref)) {
    echo json_encode(
      array('success' => false, 'message' => 'Missing required invoice fields: return_id and return_ref')
    );
    exit();
  }

  // Start transaction
  $db->beginTransaction();

  try {
    // Set invoice properties for update
    $return_invoice->return_id = $invoice_data->return_id;
    $return_invoice->return_ref = $invoice_data->return_ref;
    $return_invoice->original_pay_ref = isset($invoice_data->original_pay_ref) ? $invoice_data->original_pay_ref : '';
    $return_invoice->tot_pr = isset($invoice_data->tot_pr) ? $invoice_data->tot_pr : 0;
    $return_invoice->return_date = isset($invoice_data->return_date) ? $invoice_data->return_date : date('Y-m-d');
    $return_invoice->return_time = isset($invoice_data->return_time) ? $invoice_data->return_time : date('H:i:s');
    $return_invoice->cust_id = isset($invoice_data->cust_id) ? $invoice_data->cust_id : null;
    $return_invoice->discount = isset($invoice_data->discount) ? $invoice_data->discount : 0;
    $return_invoice->changee = isset($invoice_data->changee) ? $invoice_data->changee : 0;
    $return_invoice->user_id = isset($invoice_data->user_id) ? $invoice_data->user_id : null;
    $return_invoice->pay = isset($invoice_data->pay) ? $invoice_data->pay : 0;
    $return_invoice->store_id = isset($invoice_data->store_id) ? $invoice_data->store_id : 0;
    $return_invoice->return_method = isset($invoice_data->return_method) ? $invoice_data->return_method : '';
    $return_invoice->returnComment = isset($invoice_data->returnComment) ? $invoice_data->returnComment : '';
    $return_invoice->yearId = isset($invoice_data->yearId) ? $invoice_data->yearId : 0;
    $return_invoice->is_full_return = isset($invoice_data->is_full_return) ? $invoice_data->is_full_return : 0;
    $return_invoice->return_reason = isset($invoice_data->return_reason) ? $invoice_data->return_reason : '';

    // Update return invoice
    if (!$return_invoice->update()) {
      throw new Exception('Failed to update return invoice');
    }

    // Delete existing return details
    $return_details->return_ref = $invoice_data->return_ref;
    if (!$return_details->deleteMultiServices()) {
      throw new Exception('Failed to delete existing return items');
    }

    // Create new return items
    if (!empty($items_data) && is_array($items_data)) {
      foreach ($items_data as $item) {
        // Validate required item fields
        if (!isset($item->return_ref) || !isset($item->item_name) || 
            !isset($item->quantity) || !isset($item->item_id)) {
          throw new Exception('Missing required item fields');
        }

        // Set item properties
        $return_details->return_ref = $item->return_ref;
        $return_details->item_name = $item->item_name;
        $return_details->return_price = isset($item->return_price) ? $item->return_price : 0;
        $return_details->quantity = $item->quantity;
        $return_details->tot = isset($item->tot) ? $item->tot : 0;
        $return_details->store_id = isset($item->store_id) ? $item->store_id : $invoice_data->store_id;
        $return_details->item_id = $item->item_id;
        $return_details->dateCreated = isset($item->dateCreated) ? $item->dateCreated : date('d-m-Y');
        $return_details->original_price = isset($item->original_price) ? $item->original_price : 0;
        $return_details->yearId = isset($item->yearId) ? $item->yearId : $invoice_data->yearId;

        // Create item
        if (!$return_details->create()) {
          throw new Exception('Failed to create return item: ' . $item->item_name);
        }
      }
    }

    // Commit transaction
    $db->commit();

    // Return success response
    echo json_encode(
      array(
        'success' => true,
        'message' => 'Return invoice updated successfully',
        'return_ref' => $invoice_data->return_ref
      )
    );

  } catch (Exception $e) {
    // Rollback transaction
    $db->rollback();
    
    // Return error response
    echo json_encode(
      array(
        'success' => false,
        'message' => 'Error updating return invoice: ' . $e->getMessage()
      )
    );
  }
?>