<?php 
  // Headers
  header('Access-Control-Allow-Origin: *');
  header('Content-Type: application/json');

  include_once '../../config/Database.php';
  include_once '../../models/Sales_returns.php';

  // Instantiate DB & connect
  $database = new Database();
  $db = $database->connect();

  // Instantiate return object
  $return_invoice = new Sales_returns($db);

  // Get query parameters
  $store_id = isset($_GET['store_id']) ? $_GET['store_id'] : null;
  $from_date = isset($_GET['from_date']) ? $_GET['from_date'] : null;
  $to_date = isset($_GET['to_date']) ? $_GET['to_date'] : null;
  $yearId = isset($_GET['yearId']) ? $_GET['yearId'] : null;

  if (!$store_id || !$from_date || !$to_date || !$yearId) {
    echo json_encode(
      array('message' => 'Missing required parameters: store_id, from_date, to_date and yearId')
    );
    exit();
  }

  // Set properties
  $return_invoice->store_id = $store_id;
  $return_invoice->return_date = $from_date;
  $return_invoice->return_date2 = $to_date;
  $return_invoice->yearId = $yearId;

  // Get returns between dates
  $result = $return_invoice->getReturns2Date();
  $num = $result->rowCount();

  // Check if any returns found
  if($num > 0) {
    // Returns array
    $returns_arr = array();
    $returns_arr['data'] = array();

    while($row = $result->fetch(PDO::FETCH_ASSOC)) {
      extract($row);
      
      $return_item = array( 
        'return_id' => $return_id,
        'return_ref' => $return_ref,
        'original_pay_ref' => $original_pay_ref,
        'tot_pr' => $tot_pr,
        'return_date' => $return_date, 
        'return_time' => $return_time,
        'cust_id' => $cust_id,
        'discount' => $discount,
        'changee' => $changee,
        'user_id' => $user_id,
        'pay' => $pay,
        'store_id' => $store_id,
        'return_method' => $return_method,
        'returnComment' => $returnComment,
        'yearId' => $yearId,
        'is_full_return' => $is_full_return,
        'return_reason' => $return_reason,
        'sub_name' => $sub_name,
        'user_name' => $user_name
      );

      // Push to "data"
      array_push($returns_arr['data'], $return_item);
    }

    // Turn to JSON & output
    echo json_encode($returns_arr);

  } else {
    // No Returns Found
    echo json_encode(
      array('message' => 'No record Found')
    );
  }
?>