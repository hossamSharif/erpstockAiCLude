<?php
  header("Access-Control-Allow-Origin: *");
  header("Access-Control-Allow-Headers: access");
  header("Access-Control-Allow-Methods: GET");
  header("Content-Type: application/json; charset=UTF-8");
  header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

  require_once '../../config/Database.php';
  require_once '../../models/Purchase_returns.php';

  $database = new Database();
  $db = $database->getConnection();

  $purchaseReturn = new Purchase_returns($db);

  $original_pay_ref = isset($_GET['original_pay_ref']) ? $_GET['original_pay_ref'] : null;
  $store_id = isset($_GET['store_id']) ? $_GET['store_id'] : null;
  $yearId = isset($_GET['yearId']) ? $_GET['yearId'] : null;

  if (!$original_pay_ref || !$store_id || !$yearId) {
      http_response_code(400);
      echo json_encode(array("message" => "Missing required parameters: original_pay_ref, store_id, yearId"));
      exit();
  }

  try {
      // Create query to check for existing returns for this purchase
      $query = 'SELECT 
            return_id,
            return_ref,
            original_pay_ref,
            tot_pr,
            return_date,
            return_time,
            supplier_id,
            discount,
            is_full_return,
            return_reason
          FROM
            purchase_returns 
          WHERE 
            original_pay_ref = :original_pay_ref AND store_id = :store_id AND yearId = :yearId
          ORDER BY
            return_date DESC
          ';

      // Prepare statement
      $stmt = $db->prepare($query);

      // Bind parameters
      $stmt->bindParam(':original_pay_ref', $original_pay_ref, PDO::PARAM_STR);
      $stmt->bindParam(':store_id', $store_id, PDO::PARAM_INT);
      $stmt->bindParam(':yearId', $yearId, PDO::PARAM_INT);

      // Execute query
      $stmt->execute();

      $existingReturns = [];
      
      while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
          array_push($existingReturns, $row);
      }

      // Check if there's a full return
      $hasFullReturn = false;
      $totalReturned = 0;
      
      foreach ($existingReturns as $return) {
          if ($return['is_full_return'] == 1) {
              $hasFullReturn = true;
          }
          $totalReturned += $return['tot_pr'];
      }

      // Return response
      http_response_code(200);
      echo json_encode(array(
          "message" => count($existingReturns) > 0 ? "Existing returns found" : "No existing returns",
          "hasExistingReturns" => count($existingReturns) > 0,
          "hasFullReturn" => $hasFullReturn,
          "totalReturned" => $totalReturned,
          "existingReturns" => $existingReturns,
          "returnCount" => count($existingReturns)
      ));

  } catch (Exception $e) {
      http_response_code(500);
      echo json_encode(array(
          "message" => "Internal server error: " . $e->getMessage()
      ));
  }
?>