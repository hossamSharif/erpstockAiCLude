<?php 
  // Headers
  header('Access-Control-Allow-Origin: *');
  header('Content-Type: application/json');
  header('Access-Control-Allow-Methods: POST');
  header('Access-Control-Allow-Headers: Access-Control-Allow-Headers,Content-Type,Access-Control-Allow-Methods, Authorization, X-Requested-With');

  // Handle preflight OPTIONS request
  if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
      http_response_code(200);
      exit();
  }

include_once '../../config/Database.php';
include_once '../../models/perch.php';
include_once '../../models/perch_details.php';

// Get database connection
$database = new Database();
$db = $database->connect();

// Initialize models
$perch = new Perch($db);
$perch_details = new Perch_details($db);

// Get posted data
$raw_input = file_get_contents("php://input");
$data = json_decode($raw_input, true);

if (!$data) {
    http_response_code(400);
    echo json_encode(['message' => 'Invalid JSON data']);
    exit;
}

// Start transaction
$db->beginTransaction();

try {
    // Extract invoice data and items
    $invoiceData = $data['invoice'];
    $itemsList = $data['items'];
    
    // Validate required data
    if (!$invoiceData || !$itemsList || !is_array($itemsList)) {
        throw new Exception('Missing required invoice or items data');
    }
     $perch->pay_id = $invoiceData['pay_id'] ?? 0;
    $perch->pay_ref = $invoiceData['pay_ref'] ?? '';
    $perch->tot_pr = $invoiceData['tot_pr'] ?? 0;
    $perch->pay = $invoiceData['pay'] ?? 0;
    $perch->changee = $invoiceData['changee'] ?? 0;
    $perch->user_id = $invoiceData['user_id'] ?? 0;
    $perch->store_id = $invoiceData['store_id'] ?? 0;
    $perch->pay_date = $invoiceData['pay_date'] ?? date('Y-m-d');
    $perch->pay_time = $invoiceData['pay_time'] ?? date('H:i:s');
    $perch->nextPay = $invoiceData['nextPay'] ?? null;
    $perch->discount = $invoiceData['discount'] ?? 0;
    $perch->payComment = $invoiceData['payComment'] ?? '';
    $perch->cust_id = $invoiceData['cust_id'] ?? 0;
    $perch->pay_method = $invoiceData['pay_method'] ?? 'cash';
   
  $perch->yearId = $invoiceData['yearId'] ?? 0; 
    
    // Set invoice properties (fields that exist in the model)
    
    // Update invoice
    if (!$perch->update()) {
        throw new Exception('Unable to update invoice');
    }
    
    // Delete existing items for this invoice
    $perch_details->pay_ref = $invoiceData['pay_ref'];
    if (!$perch_details->deleteMultiServices()) {
        throw new Exception('Unable to delete existing items');
    }
    
    // Process new items
    $itemsCreated = 0;
    foreach ($itemsList as $item) {
        // Set item properties
        $perch_details->pay_ref = $invoiceData['pay_ref'];
        $perch_details->item_id = $item['item_id'];
        $perch_details->item_name = $item['item_name'];
        $perch_details->pay_price = $item['pay_price'];
        $perch_details->quantity = $item['quantity'];
        $perch_details->tot = $item['tot'];
        
        $perch_details->dateCreated = $item['dateCreated'] ?? date('Y-m-d H:i:s');
        $perch_details->perch_price = $item['perch_price'] ?? 0;
        
        $perch_details->store_id = $item['store_id'] ?? $invoiceData['store_id'] ?? 0;
  // Use item's yearId if available, fallback to invoice's yearId
      $perch_details->yearId = $item['yearId'] ?? $invoiceData['yearId'] ?? 0;
        // Create item
        if ($perch_details->create()) {
            $itemsCreated++;
        } else {
            throw new Exception('Unable to create item: ' . $item['item_name']);
        }
    }
    
    // Commit transaction
    $db->commit();
    
    // Return success response
    http_response_code(200);
    echo json_encode([
        'message' => 'Invoice and items updated successfully',
        'pay_id' => $perch->pay_id,
        'items_created' => $itemsCreated,
        'success' => true
    ]);
    
} catch (Exception $e) {
    // Rollback transaction on error
    $db->rollback();
    
    http_response_code(400);
    echo json_encode([
        'message' => 'Failed to update invoice: ' . $e->getMessage(),
        'success' => false
    ]);
}
?>