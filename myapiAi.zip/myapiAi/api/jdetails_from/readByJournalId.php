<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include_once '../../config/Database.php';
include_once '../../models/jdetails_from.php';

$database = new Database();
$db = $database->connect();

$jdetails_from = new Jdetails_from($db);

$j_id = isset($_GET['j_id']) ? $_GET['j_id'] : die();

$stmt = $jdetails_from->readByJournalId($j_id);
$num = $stmt->rowCount();

if($num>0){
    $jdetails_from_arr=array();
    $jdetails_from_arr["data"]=array();

    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
        extract($row);
        
        $jdetails_from_item=array(
            "id" => $id,
            "j_id" => $j_id,
            "j_ref" => $j_ref,
            "ac_id" => $ac_id,
            "debit" => $debit,
            "credit" => $credit,
            "j_desc" => $j_desc,
            "j_type" => $j_type,
            "store_id" => $store_id,
            "yearId" => $yearId
        );

        array_push($jdetails_from_arr["data"], $jdetails_from_item);
    }

    http_response_code(200);
    echo json_encode($jdetails_from_arr);
}
else{
    http_response_code(404);
    echo json_encode(array("message" => "No record Found."));
}
?> 