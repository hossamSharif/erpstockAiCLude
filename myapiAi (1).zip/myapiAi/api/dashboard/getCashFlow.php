<?php
header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Headers: X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Access-Control-Request-Method");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");
header("Allow: GET, POST, OPTIONS, PUT, DELETE");
header("Content-Type: application/json; charset=UTF-8");

$method = $_SERVER['REQUEST_METHOD'];
if($method == "OPTIONS") {
    die();
}

include_once '../../config/Database.php';

$database = new Database();
$db = $database->connect();

// Get parameters
$store_id = isset($_GET['store_id']) ? $_GET['store_id'] : die('{"success": false, "message": "Missing store_id parameter"}');
$start_date = isset($_GET['start_date']) ? $_GET['start_date'] : die('{"success": false, "message": "Missing start_date parameter"}');
$end_date = isset($_GET['end_date']) ? $_GET['end_date'] : die('{"success": false, "message": "Missing end_date parameter"}');
$year_id = isset($_GET['year_id']) ? $_GET['year_id'] : die('{"success": false, "message": "Missing year_id parameter"}');

try {
    // Get cash and bank account IDs (ac_id = 6 for banks, ac_id = 7 for cash)
    $cash_accounts_stmt = $db->prepare("
        SELECT id, sub_name, ac_id
        FROM sub_accounts 
        WHERE store_id = ? AND (ac_id = 6 OR ac_id = 7)
    ");
    $cash_accounts_stmt->execute([$store_id]);
    $cash_accounts = $cash_accounts_stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($cash_accounts)) {
        throw new Exception("No cash or bank accounts found");
    }
    
    $account_ids = array_column($cash_accounts, 'id');
    $placeholders = str_repeat('?,', count($account_ids) - 1) . '?';
    
    // Get Cash In (amounts in debit column from jdetails_from for cash/bank accounts)
    $cash_in_stmt = $db->prepare("
        SELECT COALESCE(SUM(jf.debit), 0) as cash_in
        FROM jdetails_from jf
        JOIN journal j ON jf.j_ref = j.j_ref
        WHERE jf.ac_id IN ($placeholders) 
        AND j.store_id = ? AND j.yearId = ? 
        AND j.j_date >= ? AND j.j_date <= ?
    ");
    $params = array_merge($account_ids, [$store_id, $year_id, $start_date, $end_date]);
    $cash_in_stmt->execute($params);
    $cash_in_result = $cash_in_stmt->fetch(PDO::FETCH_ASSOC);
    
    // Get Cash Out (amounts in credit column from jdetails_to for cash/bank accounts)
    $cash_out_stmt = $db->prepare("
        SELECT COALESCE(SUM(jt.credit), 0) as cash_out
        FROM jdetails_to jt
        JOIN journal j ON jt.j_ref = j.j_ref
        WHERE jt.ac_id IN ($placeholders) 
        AND j.store_id = ? AND j.yearId = ? 
        AND j.j_date >= ? AND j.j_date <= ?
    ");
    $cash_out_stmt->execute($params);
    $cash_out_result = $cash_out_stmt->fetch(PDO::FETCH_ASSOC);
    
    // Get daily cash flow data for chart
    $daily_cash_stmt = $db->prepare("
        SELECT 
            DATE(j.j_date) as date,
            COALESCE(SUM(CASE WHEN jf.ac_id IN ($placeholders) THEN jf.debit ELSE 0 END), 0) as cash_in_daily,
            COALESCE(SUM(CASE WHEN jt.ac_id IN ($placeholders) THEN jt.credit ELSE 0 END), 0) as cash_out_daily
        FROM journal j
        LEFT JOIN jdetails_from jf ON j.j_ref = jf.j_ref
        LEFT JOIN jdetails_to jt ON j.j_ref = jt.j_ref
        WHERE j.store_id = ? AND j.yearId = ? 
        AND j.j_date >= ? AND j.j_date <= ?
        AND (jf.ac_id IN ($placeholders) OR jt.ac_id IN ($placeholders))
        GROUP BY DATE(j.j_date)
        ORDER BY date ASC
    ");
    
    $daily_params = array_merge(
        $account_ids, // for jf.ac_id IN 
        $account_ids, // for jt.ac_id IN
        [$store_id, $year_id, $start_date, $end_date],
        $account_ids, // for jf.ac_id IN (WHERE clause)
        $account_ids  // for jt.ac_id IN (WHERE clause)
    );
    $daily_cash_stmt->execute($daily_params);
    $daily_cash_data = $daily_cash_stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Format daily data
    foreach ($daily_cash_data as &$data) {
        $data['date'] = date('Y-m-d', strtotime($data['date']));
        $data['cash_in_daily'] = floatval($data['cash_in_daily']);
        $data['cash_out_daily'] = floatval($data['cash_out_daily']);
        $data['net_daily'] = $data['cash_in_daily'] - $data['cash_out_daily'];
    }
    
    $cash_in = floatval($cash_in_result['cash_in']);
    $cash_out = floatval($cash_out_result['cash_out']);
    $net_cash_flow = $cash_in - $cash_out;
    
    // Get account details for reference
    $accounts_info = array();
    foreach ($cash_accounts as $account) {
        $accounts_info[] = array(
            "id" => $account['id'],
            "name" => $account['sub_name'],
            "type" => $account['ac_id'] == 6 ? "بنك" : "خزينة"
        );
    }
    
    $response = array(
        "success" => true,
        "data" => array(
            "cash_in" => $cash_in,
            "cash_out" => $cash_out,
            "net_cash_flow" => $net_cash_flow,
            "daily_data" => $daily_cash_data,
            "accounts_used" => $accounts_info,
            "period" => array(
                "start_date" => $start_date,
                "end_date" => $end_date
            )
        ),
        "message" => "Cash flow data retrieved successfully"
    );

    http_response_code(200);
    echo json_encode($response);

} catch(Exception $e) {
    http_response_code(500);
    echo json_encode(array(
        "success" => false,
        "message" => "Error retrieving cash flow data",
        "error" => $e->getMessage()
    ));
}
?>