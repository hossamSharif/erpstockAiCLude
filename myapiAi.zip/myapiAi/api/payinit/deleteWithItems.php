<?php 
  // Headers
  header('Access-Control-Allow-Origin: *');
  header('Content-Type: application/json');
  header('Access-Control-Allow-Methods: POST');
  header('Access-Control-Allow-Headers: Access-Control-Allow-Headers,Content-Type,Access-Control-Allow-Methods, Authorization, X-Requested-With');

  // Handle preflight OPTIONS request
  if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
      http_response_code(200);
      exit();
  }

include_once '../../config/Database.php';
include_once '../../models/payinit.php';
include_once '../../models/payinit_details.php';

// Get database connection
$database = new Database();
$db = $database->connect();

// Initialize models
$payinit = new Pay_init($db);
$payinit_details = new Pay2_details($db);

// Get posted data
$raw_input = file_get_contents("php://input");
$data = json_decode($raw_input, true);

if (!$data) {
    http_response_code(400);
    echo json_encode(['message' => 'Invalid JSON data']);
    exit;
}

// Start transaction
$db->beginTransaction();

try {
    // Validate required data
    if (!isset($data['pay_id']) || !isset($data['pay_ref'])) {
        throw new Exception('Missing required pay_id or pay_ref');
    }
    
    // Step 1: Delete from payinit_details table first (child records)
    $payinit_details->pay_ref = $data['pay_ref'];
    if (!$payinit_details->deleteMultiServices()) {
        throw new Exception('Unable to delete initial invoice items');
    }
    
    // Step 2: Delete from payinit table (parent record)
    $payinit->pay_id = $data['pay_id'];
    if (!$payinit->delete()) {
        throw new Exception('Unable to delete initial invoice');
    }
    
    // Commit transaction
    $db->commit();
    
    // Return success response
    http_response_code(200);
    echo json_encode([
        'message' => 'Initial invoice and items deleted successfully',
        'success' => true
    ]);
    
} catch (Exception $e) {
    // Rollback transaction on error
    $db->rollback();
    
    http_response_code(400);
    echo json_encode([
        'message' => 'Failed to delete initial invoice: ' . $e->getMessage(),
        'success' => false
    ]);
}
?>