<?php 
  // Headers
  header('Access-Control-Allow-Origin: *');
  header('Content-Type: application/json');

  include_once '../../config/Database.php';
  include_once '../../models/items.php';

  // Instantiate DB & connect
  $database = new Database();
  $db = $database->connect();

  // Instantiate items object
  $items = new Items($db);

  // Get parameters (pagination and category filter)
  $items->store_id = isset($_GET['store_id']) ? $_GET['store_id'] : die('{"message": "Missing store_id parameter"}');
  $page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
  $pageSize = isset($_GET['pageSize']) ? max(1, min(100, (int)$_GET['pageSize'])) : 20;
  $category_id = isset($_GET['category_id']) ? $_GET['category_id'] : null;

  try {
    // Get items with pagination and category filter
    $result = $items->readStockWithPagination($page, $pageSize, $category_id);
    
    $num = $result->rowCount();
    
    if($num > 0) {
      // Items array
      $items_arr = array();
      $items_arr['data'] = array();
      $store_tot = 0;
      $cost_tot = 0;

      while($row = $result->fetch(PDO::FETCH_ASSOC)) {
        extract($row);
        
        // Calculate quantity and stock values
        $firstQuantity = floatval($firstQuantity);
        $perchQuantity = floatval($perchQuantity);
        $salesQuantity = floatval($salesQuantity);
        $tswiaQuantity = floatval($tswiaQuantity);
        
        // Adjust for tswia differences
        if (($availQty - $qtyReal) < 0) {
          $perchQuantity += abs($availQty - $qtyReal);
        } else if (($availQty - $qtyReal) > 0) {
          $salesQuantity += ($availQty - $qtyReal);
        }
        
        $quantity = $firstQuantity + $perchQuantity - $salesQuantity;
        $stockValuePayPrice = $quantity * floatval($pay_price);
        $stockValuePerchPrice = $quantity * floatval($perch_price);
        
        // Add to totals
        $store_tot += $stockValuePayPrice;
        $cost_tot += $stockValuePerchPrice;

        $item_data = array( 
          'id' => $id,
          'item_name' => $item_name,
          'part_no' => $part_no,
          'brand' => $brand,
          'model' => $model,
          'min_qty' => $min_qty,
          'item_unit' => $item_unit,
          'pay_price' => $pay_price,
          'perch_price' => $perch_price,
          'item_desc' => $item_desc,
          'item_parcode' => $item_parcode,
          'aliasEn' => $aliasEn,
          'category_id' => $category_id,
          'category_name' => $category_name,
          'salesQuantity' => $salesQuantity,
          'perchQuantity' => $perchQuantity,
          'firstQuantity' => $firstQuantity,
          'tswiaQuantity' => $tswiaQuantity,
          'availQty' => $availQty,
          'qtyReal' => $qtyReal,
          'quantity' => $quantity,
          'stockValuePayPrice' => $stockValuePayPrice,
          'stockValuePerchPrice' => $stockValuePerchPrice,
          'lastSoldDate' => $lastSoldDate,
          'lastSoldQty' => $lastSoldQty,
          'sales28' => $sales28,
          'purch28' => $purch28
        );

        // Push to "data"
        array_push($items_arr['data'], $item_data);
      }

      // Add pagination info and totals
      $items_arr['pagination'] = array(
        'page' => $page,
        'pageSize' => $pageSize,
        'hasMore' => $num >= $pageSize
      );
      
      $items_arr['totals'] = array(
        'store_tot' => $store_tot,
        'cost_tot' => $cost_tot,
        'items_count' => $num
      );

      // Turn to JSON & output
      echo json_encode($items_arr);

    } else {
      // No items found
      echo json_encode(array(
        'message' => 'No items found',
        'data' => array(),
        'pagination' => array(
          'page' => $page,
          'pageSize' => $pageSize,
          'hasMore' => false
        ),
        'totals' => array(
          'store_tot' => 0,
          'cost_tot' => 0,
          'items_count' => 0
        )
      ));
    }
  } catch (Exception $e) {
    // Error occurred
    echo json_encode(array(
      'success' => false,
      'message' => 'Error retrieving items: ' . $e->getMessage()
    ));
  }
?>