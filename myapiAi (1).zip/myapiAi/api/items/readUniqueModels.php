<?php 
  // Headers
  header('Access-Control-Allow-Origin: *');
  header('Content-Type: application/json');

  include_once '../../config/Database.php';
  include_once '../../models/items.php';

  // Instantiate DB & connect
  $database = new Database();
  $db = $database->connect();

  // Instantiate items object
  $items = new Items($db);

  // Get parameters
  $items->store_id = isset($_GET['store_id']) ? $_GET['store_id'] : die('{"message": "Missing store_id parameter"}');
  $items->yearId = isset($_GET['yearId']) ? $_GET['yearId'] : die('{"message": "Missing yearId parameter"}');
  $brand = isset($_GET['brand']) ? $_GET['brand'] : '';
  
  try {
    // Get unique models (optionally filtered by brand)
    $result = $items->getUniqueModels($brand);
    
    $num = $result->rowCount();
    
    if($num > 0) {
      // Models array
      $models_arr = array();
      $models_arr['data'] = array();

      while($row = $result->fetch(PDO::FETCH_ASSOC)) {
        extract($row);
        $model_data = array( 
          'model' => $model,
          'brand' => $brand,
          'count' => $model_count
        );

        // Push to "data"
        array_push($models_arr['data'], $model_data);
      }

      // Turn to JSON & output
      echo json_encode($models_arr);

    } else {
      // No models found
      echo json_encode(array(
        'message' => 'No models found',
        'data' => array()
      ));
    }
  } catch (Exception $e) {
    // Error occurred
    echo json_encode(array(
      'success' => false,
      'message' => 'Error retrieving models: ' . $e->getMessage()
    ));
  }
?>