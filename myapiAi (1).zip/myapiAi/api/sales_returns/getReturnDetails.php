<?php 
  // Headers
  header('Access-Control-Allow-Origin: *');
  header('Content-Type: application/json');

  include_once '../../config/Database.php';
  include_once '../../models/Sales_return_details.php';

  // Instantiate DB & connect
  $database = new Database();
  $db = $database->connect();

  // Instantiate return details object
  $return_details = new Sales_return_details($db);

  // Get query parameters
  $store_id = isset($_GET['store_id']) ? $_GET['store_id'] : null;
  $return_ref = isset($_GET['return_ref']) ? $_GET['return_ref'] : null;
  $yearId = isset($_GET['yearId']) ? $_GET['yearId'] : null;

  if (!$store_id || !$return_ref || !$yearId) {
    echo json_encode(
      array('message' => 'Missing required parameters: store_id, return_ref and yearId')
    );
    exit();
  }

  // Set properties
  $return_details->store_id = $store_id;
  $return_details->return_ref = $return_ref;
  $return_details->yearId = $yearId;

  // Get return details
  $result = $return_details->readByStoreByRef();
  $num = $result->rowCount();

  // Check if any details found
  if($num > 0) {
    // Details array
    $details_arr = array();
    $details_arr['data'] = array();

    while($row = $result->fetch(PDO::FETCH_ASSOC)) {
      extract($row);
      
      $detail_item = array( 
        'id' => $id,
        'return_ref' => $return_ref,
        'item_name' => $item_name,
        'return_price' => $return_price,
        'quantity' => $quantity,
        'tot' => $tot,
        'store_id' => $store_id,
        'item_id' => $item_id,
        'dateCreated' => $dateCreated,
        'original_price' => $original_price,
        'yearId' => $yearId
      );

      // Push to "data"
      array_push($details_arr['data'], $detail_item);
    }

    // Turn to JSON & output
    echo json_encode($details_arr);

  } else {
    // No Details Found
    echo json_encode(
      array('message' => 'No record Found')
    );
  }
?>