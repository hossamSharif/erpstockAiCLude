<?php
// Headers
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header('Access-Control-Allow-Methods: GET');
header('Access-Control-Allow-Headers: Access-Control-Allow-Headers, Content-Type, Access-Control-Allow-Methods, Authorization, X-Requested-With');

include_once '../../config/Database.php';

try {
    // Instantiate DB & connect
    $database = new Database();
    $db = $database->connect();

    // Get parameters
    $store_id = isset($_GET['store_id']) ? (int)$_GET['store_id'] : 0;
    $item_id = isset($_GET['item_id']) ? (int)$_GET['item_id'] : 0;
    $yearId = isset($_GET['yearId']) ? (int)$_GET['yearId'] : 0;
    $start_date = isset($_GET['start_date']) ? $_GET['start_date'] : '';
    $end_date = isset($_GET['end_date']) ? $_GET['end_date'] : '';
    $group_by = isset($_GET['group_by']) ? $_GET['group_by'] : 'month'; // daily, weekly, monthly

    // Validate required parameters
    if (!$store_id || !$yearId || !$item_id) {
        http_response_code(400);
        echo json_encode(array('message' => 'Missing required parameters: store_id, yearId, and item_id'));
        exit;
    }

    // Determine date grouping format
    $date_format = '';
    $group_label = '';
    switch ($group_by) {
        case 'daily':
            $date_format = '%Y-%m-%d';
            $group_label = 'Daily';
            break;
        case 'weekly':
            $date_format = '%Y-%u';
            $group_label = 'Weekly';
            break;
        case 'monthly':
        default:
            $date_format = '%Y-%m';
            $group_label = 'Monthly';
            break;
    }

    // Build the query for trends
    $query = '
        SELECT
            DATE_FORMAT(p.pay_date, "' . $date_format . '") as period,
            pd.item_name,
            i.brand,
            i.model,
            i.part_no,
            SUM(pd.quantity) as period_quantity,
            SUM(pd.quantity * pd.pay_price) as period_revenue,
            SUM(pd.quantity * pd.perch_price) as period_cost,
            SUM(pd.quantity * (pd.pay_price - pd.perch_price)) as period_profit,
            AVG(pd.pay_price) as avg_price,
            COUNT(DISTINCT pd.pay_ref) as transaction_count,
            MIN(p.pay_date) as period_start,
            MAX(p.pay_date) as period_end
        FROM pay_details pd
        INNER JOIN pay p ON pd.pay_ref = p.pay_ref AND pd.store_id = p.store_id AND pd.yearId = p.yearId
        LEFT JOIN items i ON pd.item_id = i.id
        WHERE pd.store_id = :store_id
        AND pd.yearId = :yearId
        AND pd.item_id = :item_id
    ';

    // Add date filters if provided
    if (!empty($start_date) && !empty($end_date)) {
        $query .= ' AND p.pay_date BETWEEN :start_date AND :end_date';
    } elseif (!empty($start_date)) {
        $query .= ' AND p.pay_date >= :start_date';
    } elseif (!empty($end_date)) {
        $query .= ' AND p.pay_date <= :end_date';
    }

    $query .= '
        GROUP BY period, pd.item_name, i.brand, i.model, i.part_no
        ORDER BY period ASC
    ';

    // Prepare statement
    $stmt = $db->prepare($query);

    // Bind parameters
    $stmt->bindParam(':store_id', $store_id, PDO::PARAM_INT);
    $stmt->bindParam(':yearId', $yearId, PDO::PARAM_INT);
    $stmt->bindParam(':item_id', $item_id, PDO::PARAM_INT);

    if (!empty($start_date) && !empty($end_date)) {
        $stmt->bindParam(':start_date', $start_date);
        $stmt->bindParam(':end_date', $end_date);
    } elseif (!empty($start_date)) {
        $stmt->bindParam(':start_date', $start_date);
    } elseif (!empty($end_date)) {
        $stmt->bindParam(':end_date', $end_date);
    }

    // Execute query
    $stmt->execute();
    $num = $stmt->rowCount();

    if ($num > 0) {
        // Trends array
        $trends_arr = array();
        $trends_arr['data'] = array();
        $trends_arr['summary'] = array();

        // Initialize summary totals
        $summary = array(
            'total_periods' => 0,
            'total_quantity' => 0,
            'total_revenue' => 0,
            'total_cost' => 0,
            'total_profit' => 0,
            'total_transactions' => 0,
            'avg_quantity_per_period' => 0,
            'avg_revenue_per_period' => 0,
            'highest_quantity_period' => null,
            'highest_revenue_period' => null
        );

        $item_info = null;
        $max_quantity = 0;
        $max_revenue = 0;

        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            extract($row);

            // Store item info from first row
            if (!$item_info) {
                $item_info = array(
                    'item_id' => $item_id,
                    'item_name' => $item_name,
                    'brand' => $brand ?: '',
                    'model' => $model ?: '',
                    'part_no' => $part_no ?: ''
                );
            }

            // Calculate profit margin
            $profit_margin = $period_revenue > 0 ? (($period_profit / $period_revenue) * 100) : 0;

            $period_data = array(
                'period' => $period,
                'period_start' => $period_start,
                'period_end' => $period_end,
                'quantity' => (float)$period_quantity,
                'revenue' => (float)$period_revenue,
                'cost' => (float)$period_cost,
                'profit' => (float)$period_profit,
                'profit_margin' => (float)$profit_margin,
                'avg_price' => (float)$avg_price,
                'transaction_count' => (int)$transaction_count,
                'avg_quantity_per_transaction' => $transaction_count > 0 ?
                    (float)($period_quantity / $transaction_count) : 0
            );

            // Update summary
            $summary['total_periods']++;
            $summary['total_quantity'] += (float)$period_quantity;
            $summary['total_revenue'] += (float)$period_revenue;
            $summary['total_cost'] += (float)$period_cost;
            $summary['total_profit'] += (float)$period_profit;
            $summary['total_transactions'] += (int)$transaction_count;

            // Track highest periods
            if ($period_quantity > $max_quantity) {
                $max_quantity = $period_quantity;
                $summary['highest_quantity_period'] = $period;
            }
            if ($period_revenue > $max_revenue) {
                $max_revenue = $period_revenue;
                $summary['highest_revenue_period'] = $period;
            }

            array_push($trends_arr['data'], $period_data);
        }

        // Calculate averages
        $summary['avg_quantity_per_period'] = $summary['total_periods'] > 0 ?
            ($summary['total_quantity'] / $summary['total_periods']) : 0;
        $summary['avg_revenue_per_period'] = $summary['total_periods'] > 0 ?
            ($summary['total_revenue'] / $summary['total_periods']) : 0;
        $summary['overall_profit_margin'] = $summary['total_revenue'] > 0 ?
            (($summary['total_profit'] / $summary['total_revenue']) * 100) : 0;

        $trends_arr['summary'] = $summary;
        $trends_arr['item_info'] = $item_info;
        $trends_arr['grouping'] = array(
            'type' => $group_by,
            'label' => $group_label
        );
        $trends_arr['filters_applied'] = array(
            'store_id' => $store_id,
            'yearId' => $yearId,
            'item_id' => $item_id,
            'start_date' => $start_date,
            'end_date' => $end_date,
            'group_by' => $group_by
        );

        // Return JSON response
        echo json_encode($trends_arr);

    } else {
        // No data found
        echo json_encode(array(
            'message' => 'No record Found',
            'data' => array(),
            'summary' => array(),
            'item_info' => array('item_id' => $item_id)
        ));
    }

} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(array('message' => 'Database error: ' . $e->getMessage()));
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(array('message' => 'Server error: ' . $e->getMessage()));
}
?>