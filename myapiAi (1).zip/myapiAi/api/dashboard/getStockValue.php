<?php
header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Headers: X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Access-Control-Request-Method");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");
header("Allow: GET, POST, OPTIONS, PUT, DELETE");
header("Content-Type: application/json; charset=UTF-8");

$method = $_SERVER['REQUEST_METHOD'];
if($method == "OPTIONS") {
    die();
}

include_once '../../config/Database.php';
include_once '../../models/items.php';

// Instantiate DB & connect
$database = new Database();
$db = $database->connect();

// Instantiate items object
$items = new Items($db);

// Get parameters (same as readStockTotals.php approach)
$items->store_id = isset($_GET['store_id']) ? $_GET['store_id'] : die('{"success": false, "message": "Missing store_id parameter"}');
$items->yearId = isset($_GET['year_id']) ? $_GET['year_id'] : die('{"success": false, "message": "Missing year_id parameter"}');

// Set category to 'all' to get totals for all categories (same as readStockTotals.php default)
$items->category_id = 'all';

try {
    // Get stock totals using the same method as readStockTotals.php
    $result = $items->getStockTotals();
    
    if($result) {
        // Map the result to match dashboard expectations
        // readStockTotals.php returns: stockValuePayPrice, stockValuePerchPrice, items_count
        $response = array(
            "success" => true,
            "data" => array(
                "payPrice" => floatval($result['stockValuePayPrice']) ?: 0,
                "purchPrice" => floatval($result['stockValuePerchPrice']) ?: 0,
                "potential_profit" => (floatval($result['stockValuePayPrice']) ?: 0) - (floatval($result['stockValuePerchPrice']) ?: 0),
                "total_items" => intval($result['items_count']) ?: 0,
                "items_with_stock" => intval($result['items_count']) ?: 0, // Same as total for this calculation method
                "average_markup" => $result['stockValuePerchPrice'] > 0 ? 
                    ((floatval($result['stockValuePayPrice']) - floatval($result['stockValuePerchPrice'])) / floatval($result['stockValuePerchPrice'])) * 100 : 0
            ),
            "message" => "Stock value data retrieved successfully using Items model approach"
        );
        
        http_response_code(200);
        echo json_encode($response);
        
    } else {
        // No data found - return zeros (same as readStockTotals.php)
        $response = array(
            "success" => true,
            "data" => array(
                "payPrice" => 0,
                "purchPrice" => 0,
                "potential_profit" => 0,
                "total_items" => 0,
                "items_with_stock" => 0,
                "average_markup" => 0
            ),
            "message" => "No stock data found"
        );
        
        http_response_code(200);
        echo json_encode($response);
    }

} catch(Exception $e) {
    http_response_code(500);
    echo json_encode(array(
        "success" => false,
        "message" => "Error retrieving stock value data",
        "error" => $e->getMessage()
    ));
}
?>